import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# --------------------------- Attention ---------------------------

class TemporalAttention(layers.Layer):
    def __init__(self, attn_units: int = 64, **kwargs):
        super().__init__(**kwargs)
        self.attn_units = attn_units
        self.W = layers.Dense(attn_units)
        self.V = layers.Dense(1)

    def call(self, inputs):
        # inputs: (batch, T, F)
        score = self.V(tf.nn.tanh(self.W(inputs)))      # (batch, T, 1)
        weights = tf.nn.softmax(score, axis=1)           # (batch, T, 1)
        context = tf.reduce_sum(weights * inputs, axis=1)  # (batch, F)
        return context

    def get_config(self):
        cfg = super().get_config()
        cfg.update({"attn_units": self.attn_units})
        return cfg

# --------------------------- Positional Encoding ---------------------------

class PositionalEncoding(layers.Layer):
    """
    Classic sine-cosine positional encoding that matches input's (T, F).
    Works for any even/odd F by padding if needed.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, x):
        # x: (batch, T, F)
        T = tf.shape(x)[1]
        F = tf.shape(x)[2]

        # Build [T, F] encoding
        pos = tf.cast(tf.range(T)[:, tf.newaxis], tf.float32)   # (T,1)
        i = tf.cast(tf.range(F)[tf.newaxis, :], tf.float32)     # (1,F)
        angle_rates = 1.0 / tf.pow(10000.0, (2.0 * tf.floor(i/2.0)) / tf.cast(F, tf.float32))
        angle_rads = pos * angle_rates                           # (T,F)

        # Apply sin to even indices in the array; cos to odd indices
        sines = tf.sin(angle_rads[:, 0::2])
        coses = tf.cos(angle_rads[:, 1::2])

        # If F is odd, pad cos or sin to match F
        def _interleave(sin, cos):
            # sin: (T, ceil(F/2)), cos: (T, floor(F/2))
            sin_exp = tf.reshape(sin, (T, -1, 1))
            cos_exp = tf.reshape(cos, (T, -1, 1))
            min_len = tf.minimum(tf.shape(sin_exp)[1], tf.shape(cos_exp)[1])
            pair = tf.reshape(tf.stack([sin_exp[:, :min_len], cos_exp[:, :min_len]], axis=3), (T, -1))
            if tf.math.not_equal(F % 2, 0):
                # one extra sine channel if F is odd
                pair = tf.concat([pair, sin[:, -1:]], axis=1)
            return pair  # (T,F)
        pe = _interleave(sines, coses)  # (T,F)

        pe = tf.expand_dims(pe, axis=0)  # (1,T,F) to broadcast across batch
        return x + pe

    def get_config(self):
        return {}

# --------------------------- Transformer Block ---------------------------

class TransformerBlock(layers.Layer):
    def __init__(self, num_heads=4, key_dim=32, ff_dim=128, dropout=0.1, **kwargs):
        super().__init__(**kwargs)
        self.mha = layers.MultiHeadAttention(num_heads=num_heads, key_dim=key_dim)
        self.dropout1 = layers.Dropout(dropout)
        self.norm1 = layers.LayerNormalization(epsilon=1e-6)

        self.ffn = keras.Sequential([
            layers.Dense(ff_dim, activation='relu'),
            layers.Dense(ff_dim // 2, activation='relu')
        ])
        self.dropout2 = layers.Dropout(dropout)
        self.norm2 = layers.LayerNormalization(epsilon=1e-6)

    def call(self, x, training=False):
        attn_output = self.mha(x, x, training=training)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.norm1(x + attn_output)

        ffn_output = self.ffn(out1, training=training)
        ffn_output = self.dropout2(ffn_output, training=training)
        out2 = self.norm2(out1 + ffn_output)
        return out2

# --------------------------- Loss ---------------------------

def weighted_huber_directional_loss(horizon_weights=None, delta=0.001, lambda_dir=0.05):
    def huber(y_true, y_pred):
        err = y_true - y_pred
        abs_err = tf.abs(err)
        quad = tf.minimum(abs_err, delta)
        lin = abs_err - quad
        return 0.5 * tf.square(quad) / delta + delta * lin
    def loss(y_true, y_pred):
        H = tf.shape(y_true)[1]
        if horizon_weights is None:
            w = tf.linspace(1.0, 0.6, H)
        else:
            w = tf.constant(horizon_weights, dtype=tf.float32)
        w = w / (tf.reduce_sum(w) + 1e-12)

        hub = huber(y_true, y_pred)
        hub = tf.reduce_mean(hub, axis=0)
        hub = tf.reduce_sum(hub * w)

        diff_true = y_true[:, 1:] - y_true[:, :-1]
        diff_pred = y_pred[:, 1:] - y_pred[:, :-1]
        sign_agree = diff_true * diff_pred
        dir_penalty = tf.nn.relu(-sign_agree)
        dir_penalty = tf.reduce_mean(dir_penalty)
        return hub + lambda_dir * dir_penalty
    return loss

# --------------------------- Full Model ---------------------------

def build_fused_model(sequence_length: int,
                      n_features: int,
                      prediction_steps: int,
                      attn_units: int = 64,
                      transformer_heads: int = 4,
                      transformer_keydim: int = 32,
                      transformer_ff: int = 128,
                      dropout: float = 0.2,
                      horizon_weights=None) -> keras.Model:
    inp = layers.Input(shape=(sequence_length, n_features), name="features")

    # ----- Branch A: CNN + BiLSTM -----
    a = layers.Conv1D(64, 5, activation='relu', padding='causal')(inp)
    a = layers.BatchNormalization()(a)
    a = layers.Conv1D(64, 3, activation='relu', padding='causal')(a)
    a = layers.MaxPooling1D(2)(a)
    a = layers.Dropout(dropout)(a)

    a = layers.Conv1D(64, 3, activation='relu', padding='causal')(a)
    a = layers.BatchNormalization()(a)
    a = layers.Conv1D(64, 3, activation='relu', padding='causal')(a)
    a = layers.MaxPooling1D(2)(a)
    a = layers.Dropout(dropout)(a)

    # FIX: Change LSTM units from 128 to 32.
    # The Bidirectional layer concatenates forward (32) and backward (32) passes,
    # resulting in an output dimension of 64, which now matches Branch B.
    a = layers.Bidirectional(layers.LSTM(32, return_sequences=True))(a)
    a = layers.Dropout(0.3)(a)
    ctx_a = TemporalAttention(attn_units=attn_units, name="attn_cnn_bilstm")(a)

    # ----- Branch B: Project -> PositionalEncoding -> Transformer -----
    b = layers.Dense(64, activation='linear')(inp)  # project to d_model
    b = PositionalEncoding()(b)
    for i in range(2):
        b = TransformerBlock(num_heads=transformer_heads, key_dim=transformer_keydim,
                             ff_dim=transformer_ff, dropout=dropout, name=f"txblock_{i+1}")(b)
    ctx_b = TemporalAttention(attn_units=attn_units, name="attn_transformer")(b)

    # ----- Gated fusion -----
    fuse = layers.Concatenate()([ctx_a, ctx_b])
    gate = layers.Dense(1, activation='sigmoid', name='gate')(fuse)
    fused = gate * ctx_a + (1.0 - gate) * ctx_b

    x = layers.Dense(128, activation='relu')(fused)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(0.25)(x)
    x = layers.Dense(64, activation='relu')(x)
    out = layers.Dense(prediction_steps, name='predictions')(x)

    model = keras.Model(inputs=inp, outputs=out, name="FUSED_CNN_BiLSTM_Transformer_Attn")

    loss_fn = weighted_huber_directional_loss(horizon_weights=horizon_weights, delta=0.001, lambda_dir=0.05)
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss=loss_fn, metrics=['mae'])
    return model