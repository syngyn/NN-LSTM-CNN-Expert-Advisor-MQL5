import json
import logging
import numpy as np
import pandas as pd
from datetime import datetime
from pathlib import Path
import traceback

from flask import Flask, request, jsonify, Response
from flask_cors import CORS
import joblib
from tensorflow.keras.models import load_model

from model_attn_transformer import TemporalAttention, PositionalEncoding, TransformerBlock
from features import compute_features

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# --- FIX: Define paths for BOTH H1 and D1 models ---
H1_MODEL_DIR = Path('models_EURUSD_H1_plus')
D1_MODEL_DIR = Path('models_EURUSD_D1_plus')

# --- Helper function to load model artifacts to reduce code duplication ---
def load_model_artifacts(model_dir: Path, model_name: str):
    if not model_dir.exists():
        raise FileNotFoundError(f"Model directory not found: {model_dir}")
    
    model_path = model_dir / model_name
    scaler_path = model_dir / 'feature_scaler.pkl'
    price_scaler_path = model_dir / 'price_scaler.pkl'
    config_path = model_dir / 'model_config.json'

    custom_objects = {
        'TemporalAttention': TemporalAttention,
        'PositionalEncoding': PositionalEncoding,
        'TransformerBlock': TransformerBlock,
        'loss': lambda y, t: 0.0 # Dummy loss for inference
    }
    model = load_model(model_path, custom_objects=custom_objects, compile=False)
    model.compile(loss='mse')
    
    feature_scaler = joblib.load(scaler_path)
    price_scaler = joblib.load(price_scaler_path)
    config = json.loads(config_path.read_text(encoding='utf-8'))
    
    logger.info(f"Loaded model artifacts from {model_dir}")
    return model, feature_scaler, price_scaler, config

# --- FIX: Load both H1 and D1 models and their artifacts ---
h1_model, h1_feature_scaler, h1_price_scaler, h1_config = load_model_artifacts(H1_MODEL_DIR, 'best_attention_plus_model.h5')
d1_model, d1_feature_scaler, d1_price_scaler, d1_config = load_model_artifacts(D1_MODEL_DIR, 'best_attention_plus_model_D1.h5')

# Extract configs
H1_SEQ_LEN = int(h1_config['sequence_length'])
H1_N_FEATURES = int(h1_config['n_features'])
H1_FEATURE_COLS = h1_config['feature_columns']

D1_SEQ_LEN = int(d1_config['sequence_length'])
D1_N_FEATURES = int(d1_config['n_features'])
D1_FEATURE_COLS = d1_config['feature_columns']

def _ensure_feature_order(df: pd.DataFrame, expected_cols: list) -> pd.DataFrame:
    df_reordered = pd.DataFrame(columns=expected_cols, index=df.index)
    common_cols = [col for col in expected_cols if col in df.columns]
    df_reordered[common_cols] = df[common_cols]
    return df_reordered.fillna(0.0)

@app.route('/predict_ohlcv_plus', methods=['POST'])
def predict_ohlcv_plus() -> Response:
    try:
        data = request.get_json()
        h1_bars_json = data.get('bars', [])
        if not h1_bars_json:
            return jsonify({'error': 'No bars provided'}), 400

        # --- Process H1 Data for HOURLY Prediction ---
        df_h1 = pd.DataFrame(h1_bars_json)
        df_h1['timestamp'] = pd.to_datetime(df_h1['timestamp'])
        df_h1 = df_h1.sort_values('timestamp').set_index('timestamp')
        
        h1_feat_df = compute_features(df_h1)
        h1_feat_ordered = _ensure_feature_order(h1_feat_df, H1_FEATURE_COLS)
        
        if len(h1_feat_ordered) < H1_SEQ_LEN:
             return jsonify({'error': f"Not enough H1 data for sequence. Need {H1_SEQ_LEN}, got {len(h1_feat_ordered)}."}), 400

        h1_scaled = h1_feature_scaler.transform(h1_feat_ordered.values)
        h1_seq = h1_scaled[-H1_SEQ_LEN:].reshape(1, H1_SEQ_LEN, H1_N_FEATURES)
        h1_pred_scaled = h1_model.predict(h1_seq, verbose=0)
        hourly_predictions = h1_price_scaler.inverse_transform(h1_pred_scaled)[0].tolist()

        # --- Process D1 Data for DAILY Prediction ---
        # We need to resample the provided H1 bars into D1 bars
        df_d1 = df_h1['close'].resample('D').last().dropna().to_frame()
        df_d1['open'] = df_h1['open'].resample('D').first().dropna()
        df_d1['high'] = df_h1['high'].resample('D').max().dropna()
        df_d1['low'] = df_h1['low'].resample('D').min().dropna()
        df_d1['volume'] = df_h1['volume'].resample('D').sum().dropna()
        df_d1.dropna(inplace=True)
        
        d1_feat_df = compute_features(df_d1)
        d1_feat_ordered = _ensure_feature_order(d1_feat_df, D1_FEATURE_COLS)

        if len(d1_feat_ordered) < D1_SEQ_LEN:
             return jsonify({'error': f"Not enough D1 data after resampling. Need {D1_SEQ_LEN}, got {len(d1_feat_ordered)}."}), 400

        d1_scaled = d1_feature_scaler.transform(d1_feat_ordered.values)
        d1_seq = d1_scaled[-D1_SEQ_LEN:].reshape(1, D1_SEQ_LEN, D1_N_FEATURES)
        d1_pred_scaled = d1_model.predict(d1_seq, verbose=0)
        daily_predictions = d1_price_scaler.inverse_transform(d1_pred_scaled)[0].tolist()

        # --- Combine predictions and send response ---
        return jsonify({
            'success': True,
            'timestamp': datetime.now().isoformat(),
            'hourly': hourly_predictions,
            'daily': daily_predictions
        })

    except Exception as e:
        logger.error(f"/predict_ohlcv_plus error: {e}")
        logger.error(traceback.format_exc())
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    print("Server starting with dual H1/D1 model support...")
    print(f"H1 Model Seq Len: {H1_SEQ_LEN}, D1 Model Seq Len: {D1_SEQ_LEN}")
    app.run(host='0.0.0.0', port=8000, debug=False)