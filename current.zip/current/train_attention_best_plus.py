import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error
import joblib

from tensorflow.keras import callbacks
from model_attn_transformer import build_fused_model
from features import compute_features, ensure_column_order

def convert_numpy_types(obj):
    """
    Recursively convert numpy types to Python types for JSON serialization.
    """
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, dict):
        return {key: convert_numpy_types(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(item) for item in obj]
    else:
        return obj

def load_exogenous(exo_csvs):
    """
    Load and merge one or more CSVs with a 'timestamp' column.
    All other columns are treated as exogenous numeric features.
    Returns a DataFrame indexed by timestamp.
    """
    if not exo_csvs:
        return None

    merged = None
    for p in exo_csvs:
        df = pd.read_csv(p, parse_dates=['timestamp'])
        df.set_index('timestamp', inplace=True)
        # keep only numeric columns
        numcols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
        df = df[numcols].astype(float)
        merged = df if merged is None else merged.join(df, how='outer')
    merged.sort_index(inplace=True)
    merged = merged.dropna(how='all')
    return merged

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--raw_csv', default='EURUSD_H1_raw.csv', help='OHLCV CSV from MT5 or fallback')
    ap.add_argument('--exo_csv', nargs='*', default=[], help='List of CSVs with exogenous series (must have timestamp)')
    ap.add_argument('--seq_len', type=int, default=128)
    ap.add_argument('--pred_steps', type=int, default=5)
    ap.add_argument('--epochs', type=int, default=60)
    ap.add_argument('--splits', type=int, default=4)
    ap.add_argument('--out_dir', default='models_EURUSD_H1_plus')
    ap.add_argument('--horizon_weights', nargs='*', type=float, default=[1.0,0.9,0.8,0.7,0.6])
    args = ap.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    # --- Load OHLCV ---
    df_raw = pd.read_csv(args.raw_csv, parse_dates=['timestamp']).set_index('timestamp')
    df_raw = df_raw[['open','high','low','close','volume']].dropna()

    # --- Exogenous (optional) ---
    exo = load_exogenous(args.exo_csv)
    if exo is not None:
        # align to OHLCV timeline (forward-fill reasonable for macro data)
        exo = exo.reindex(df_raw.index).ffill().bfill()

    # --- Compute technical features ---
    df_feat = compute_features(df_raw)
    core = ensure_column_order(df_feat)  # (open..stochastic)

    if exo is not None:
        # Append exo columns to feature matrix
        full = core.join(exo, how='inner')  # ensure alignment
        exo_cols = list(exo.columns)
    else:
        full = core.copy()
        exo_cols = []

    full.dropna(inplace=True)

    prices = full['close'].values.reshape(-1,1)
    feature_cols = [c for c in full.columns if c != 'close']  # keep close also as feature because order matters?
    # IMPORTANT: maintain original order for the first 12 core features, then exo appended
    core_cols = ['open','high','low','close','volume','rsi','macd','ma_20','bb_upper','bb_lower','atr','stochastic']
    for c in core_cols:
        if c not in feature_cols:
            feature_cols.insert(len(feature_cols), c)  # ensure presence; fallback
    # rebuild ordered feature matrix
    feature_cols = core_cols + [c for c in feature_cols if c not in core_cols]
    feats = full[feature_cols].values
    n_features = feats.shape[1]

    # --- CV ---
    tscv = TimeSeriesSplit(n_splits=args.splits)
    best_val = float('inf')
    best_path = out / 'best_attention_plus_model.h5'
    hist_all = []

    fold = 0
    for train_idx, val_idx in tscv.split(feats):
        fold += 1
        Xtr_raw, Xva_raw = feats[train_idx], feats[val_idx]
        ytr_raw, yva_raw = prices[train_idx], prices[val_idx]

        feat_scaler = MinMaxScaler()
        price_scaler = MinMaxScaler()
        Xtr = feat_scaler.fit_transform(Xtr_raw)
        ytr = price_scaler.fit_transform(ytr_raw).flatten()

        Xva = feat_scaler.transform(Xva_raw)
        yva = price_scaler.transform(yva_raw).flatten()

        # sequences
        def make_seq(F, P):
            X, y = [], []
            L = args.seq_len
            H = args.pred_steps
            for i in range(L, len(F) - H):
                X.append(F[i-L:i])
                y.append(P[i:i+H])
            return np.array(X), np.array(y)

        Xtr_seq, ytr_seq = make_seq(Xtr, ytr)
        Xva_seq, yva_seq = make_seq(Xva, yva)

        model = build_fused_model(sequence_length=args.seq_len,
                                  n_features=n_features,
                                  prediction_steps=args.pred_steps,
                                  attn_units=64,
                                  transformer_heads=4,
                                  transformer_keydim=32,
                                  transformer_ff=128,
                                  dropout=0.2,
                                  horizon_weights=args.horizon_weights)

        cbs = [
            callbacks.EarlyStopping(patience=10, restore_best_weights=True, monitor='val_loss'),
            callbacks.ReduceLROnPlateau(factor=0.5, patience=5, monitor='val_loss'),
            callbacks.ModelCheckpoint(str(out / f'fold{fold}_weights.h5'), save_best_only=True, monitor='val_loss')
        ]

        hist = model.fit(Xtr_seq, ytr_seq,
                         validation_data=(Xva_seq, yva_seq),
                         epochs=args.epochs,
                         batch_size=64,
                         verbose=1,
                         shuffle=True,
                         callbacks=cbs)
        hist_all.append(hist.history)

        # Validation in original scale
        va_pred_scaled = model.predict(Xva_seq, verbose=0)
        yva_seq_2d = yva_seq.reshape(-1, args.pred_steps)
        va_pred = price_scaler.inverse_transform(va_pred_scaled)
        yva_unscaled = price_scaler.inverse_transform(yva_seq_2d)

        mse = mean_squared_error(yva_unscaled.flatten(), va_pred.flatten())
        mae = mean_absolute_error(yva_unscaled.flatten(), va_pred.flatten())
        print(f"[fold {fold}] Val MSE: {mse:.8f}  MAE: {mae:.6f}")

        if mse < best_val:
            best_val = mse
            model.save(best_path)
            # Save scalers and config
            joblib.dump(feat_scaler, out / 'feature_scaler.pkl')
            joblib.dump(price_scaler, out / 'price_scaler.pkl')
            cfg = {
                'sequence_length': args.seq_len,
                'n_features': int(n_features),
                'prediction_steps': args.pred_steps,
                'attn_units': 64,
                'transformer': {'heads': 4, 'keydim': 32, 'ff': 128},
                'dropout': 0.2,
                'horizon_weights': args.horizon_weights,
                'feature_columns': feature_cols,
                'exo_columns': exo_cols
            }
            (out / 'model_config.json').write_text(json.dumps(cfg, indent=2), encoding='utf-8')

    # Convert numpy types before JSON serialization
    hist_all_converted = convert_numpy_types(hist_all)
    (out / 'history_plus.json').write_text(json.dumps(hist_all_converted, indent=2), encoding='utf-8')
    print(f"[ok] Best model saved to {best_path}  (best Val MSE: {best_val:.8f})")

if __name__ == '__main__':
    main()