#!/usr/bin/env python3
"""
Real H1 Prediction Generator
Uses your actual trained LSTM CNN model to generate legitimate predictions
Compatible with the H1 AI Scalping Backtesting system
"""

import os
import json
import numpy as np
import pandas as pd
import joblib
import logging
from datetime import datetime, timedelta
from typing import List, Tuple, Optional
import warnings

# Import ML libraries with error handling
try:
    import tensorflow as tf
    from tensorflow.keras.models import load_model
    ML_AVAILABLE = True
except ImportError as e:
    print(f"Warning: TensorFlow not available: {e}")
    ML_AVAILABLE = False

warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class RealH1Predictor:
    """Real H1 prediction generator using your trained LSTM CNN model"""
    
    def __init__(self, model_dir=".", sequence_length=60, n_features=12):
        self.model_dir = model_dir
        self.sequence_length = sequence_length
        self.n_features = n_features
        self.prediction_steps = 5
        
        # Model components
        self.model = None
        self.price_scaler = None
        self.feature_scaler = None
        self.config = None
        self.is_loaded = False
        
        # Feature columns in EXACT same order as training
        self.feature_columns = [
            'open', 'high', 'low', 'close', 'volume',
            'rsi', 'macd', 'ma_20', 'bb_upper', 'bb_lower', 'atr', 'stochastic'
        ]
        
        # Load the trained model
        self.load_trained_model()
    
    def load_trained_model(self) -> bool:
        """Load your pre-trained model and scalers"""
        try:
            model_path = os.path.join(self.model_dir, "lstm_cnn_model.h5")
            config_path = os.path.join(self.model_dir, "model_config.json")
            price_scaler_path = os.path.join(self.model_dir, "price_scaler.pkl")
            feature_scaler_path = os.path.join(self.model_dir, "feature_scaler.pkl")
            
            # Check if all required files exist
            required_files = [model_path, config_path, price_scaler_path, feature_scaler_path]
            missing_files = [f for f in required_files if not os.path.exists(f)]
            
            if missing_files:
                logger.error(f"Missing model files: {missing_files}")
                logger.error("Please run train_model.py first to create the trained model")
                return False
            
            if not ML_AVAILABLE:
                logger.error("TensorFlow not available. Install with: pip install tensorflow")
                return False
            
            # Load model
            logger.info(f"Loading trained model from {model_path}")
            self.model = load_model(model_path)
            
            # Load configuration
            with open(config_path, 'r') as f:
                self.config = json.load(f)
                self.sequence_length = self.config['sequence_length']
                self.n_features = self.config['n_features']
                self.prediction_steps = self.config['prediction_steps']
            
            # Load scalers
            self.price_scaler = joblib.load(price_scaler_path)
            self.feature_scaler = joblib.load(feature_scaler_path)
            
            self.is_loaded = True
            
            logger.info("✅ Real model loaded successfully!")
            logger.info(f"   Model: {model_path}")
            logger.info(f"   Sequence length: {self.sequence_length}")
            logger.info(f"   Features: {self.n_features}")
            logger.info(f"   Prediction steps: {self.prediction_steps}")
            logger.info(f"   Price scaler range: {self.price_scaler.feature_range}")
            
            # Test the model with a quick prediction
            self._test_model()
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to load trained model: {e}")
            logger.error("Make sure to run train_model.py first")
            return False
    
    def _test_model(self):
        """Test the model with dummy data to ensure it works"""
        try:
            # Create dummy data matching the expected input shape
            dummy_data = np.random.random((1, self.sequence_length, self.n_features))
            
            # Make prediction
            prediction = self.model.predict(dummy_data, verbose=0)
            
            logger.info(f"Model test successful - Output shape: {prediction.shape}")
            
        except Exception as e:
            logger.warning(f"Model test failed: {e}")
    
    def create_market_data_from_ohlc(self, ohlc_data: np.ndarray) -> pd.DataFrame:
        """
        Create market data DataFrame from OHLC data
        Input: ohlc_data should be numpy array with columns [open, high, low, close, volume]
        """
        if ohlc_data.shape[1] < 5:
            raise ValueError(f"OHLC data must have at least 5 columns [O,H,L,C,V], got {ohlc_data.shape[1]}")
        
        df = pd.DataFrame(ohlc_data, columns=['open', 'high', 'low', 'close', 'volume'])
        
        # Calculate technical indicators (same as in training)
        logger.info("Calculating technical indicators...")
        
        # RSI
        df['rsi'] = self._calculate_rsi(df['close'])
        
        # MACD
        df['macd'] = self._calculate_macd(df['close'])
        
        # Moving Average
        df['ma_20'] = df['close'].rolling(window=20).mean()
        
        # Bollinger Bands
        bb_period = 20
        bb_std = 2
        ma_bb = df['close'].rolling(window=bb_period).mean()
        bb_std_dev = df['close'].rolling(window=bb_period).std()
        df['bb_upper'] = ma_bb + (bb_std_dev * bb_std)
        df['bb_lower'] = ma_bb - (bb_std_dev * bb_std)
        
        # ATR
        df['atr'] = self._calculate_atr(df[['high', 'low', 'close']])
        
        # Stochastic
        df['stochastic'] = self._calculate_stochastic(df[['high', 'low', 'close']])
        
        # Fill NaN values with forward fill then backward fill
        df = df.fillna(method='ffill').fillna(method='bfill')
        
        # If still NaN, fill with reasonable defaults
        df['rsi'] = df['rsi'].fillna(50.0)
        df['macd'] = df['macd'].fillna(0.0)
        df['ma_20'] = df['ma_20'].fillna(df['close'])
        df['bb_upper'] = df['bb_upper'].fillna(df['close'] * 1.02)
        df['bb_lower'] = df['bb_lower'].fillna(df['close'] * 0.98)
        df['atr'] = df['atr'].fillna(0.001)
        df['stochastic'] = df['stochastic'].fillna(50.0)
        
        logger.info(f"Created market data with {len(df)} bars")
        logger.info(f"Price range: [{df['close'].min():.5f}, {df['close'].max():.5f}]")
        
        return df
    
    def _calculate_rsi(self, prices: pd.Series, period: int = 14) -> pd.Series:
        """Calculate RSI indicator"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def _calculate_macd(self, prices: pd.Series, fast: int = 12, slow: int = 26) -> pd.Series:
        """Calculate MACD indicator"""
        exp1 = prices.ewm(span=fast).mean()
        exp2 = prices.ewm(span=slow).mean()
        macd = exp1 - exp2
        return macd
    
    def _calculate_atr(self, hlc_data: pd.DataFrame, period: int = 14) -> pd.Series:
        """Calculate ATR indicator"""
        high = hlc_data['high']
        low = hlc_data['low']
        close = hlc_data['close']
        
        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(window=period).mean()
        
        return atr * 10000  # Convert to points
    
    def _calculate_stochastic(self, hlc_data: pd.DataFrame, k_period: int = 14) -> pd.Series:
        """Calculate Stochastic oscillator"""
        high = hlc_data['high']
        low = hlc_data['low']
        close = hlc_data['close']
        
        lowest_low = low.rolling(window=k_period).min()
        highest_high = high.rolling(window=k_period).max()
        
        k_percent = 100 * ((close - lowest_low) / (highest_high - lowest_low))
        
        return k_percent
    
    def generate_h1_prediction(self, market_data: pd.DataFrame) -> Tuple[float, dict]:
        """
        Generate H1 prediction using the trained model
        Returns: (predicted_price, prediction_info)
        """
        if not self.is_loaded:
            raise ValueError("Model not loaded. Check if training files exist.")
        
        if len(market_data) < self.sequence_length:
            raise ValueError(f"Need at least {self.sequence_length} bars, got {len(market_data)}")
        
        try:
            # Prepare features in exact same order as training
            features = self._prepare_features(market_data)
            
            # Take the last sequence_length bars
            last_sequence = features[-self.sequence_length:]
            
            # Scale features using the trained scaler
            last_sequence_scaled = self.feature_scaler.transform(last_sequence)
            
            # Reshape for model input: (1, sequence_length, n_features)
            model_input = last_sequence_scaled.reshape(1, self.sequence_length, self.n_features)
            
            # Make prediction (scaled output)
            prediction_scaled = self.model.predict(model_input, verbose=0)[0]
            
            # Unscale predictions to real prices
            prediction_scaled_reshaped = prediction_scaled.reshape(-1, 1)
            hourly_predictions = self.price_scaler.inverse_transform(prediction_scaled_reshaped).flatten()
            
            # Get current price and H1 prediction
            current_price = market_data['close'].iloc[-1]
            h1_prediction = hourly_predictions[0]  # First prediction is H1
            
            # Calculate prediction change
            change_pct = ((h1_prediction - current_price) / current_price) * 100
            
            # Prepare prediction info
            prediction_info = {
                'current_price': float(current_price),
                'h1_prediction': float(h1_prediction),
                'change_percent': float(change_pct),
                'direction': 'BUY' if change_pct > 0 else 'SELL',
                'all_hourly_predictions': [float(x) for x in hourly_predictions],
                'prediction_time': datetime.now().isoformat(),
                'model_confidence': self._calculate_confidence(model_input, hourly_predictions),
                'technical_indicators': {
                    'rsi': float(market_data['rsi'].iloc[-1]),
                    'macd': float(market_data['macd'].iloc[-1]),
                    'atr': float(market_data['atr'].iloc[-1]),
                    'stochastic': float(market_data['stochastic'].iloc[-1])
                }
            }
            
            logger.info(f"H1 Prediction Generated:")
            logger.info(f"  Current Price: {current_price:.5f}")
            logger.info(f"  H1 Prediction: {h1_prediction:.5f}")
            logger.info(f"  Change: {change_pct:+.3f}%")
            logger.info(f"  Direction: {prediction_info['direction']}")
            
            return h1_prediction, prediction_info
            
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            raise
    
    def _prepare_features(self, market_data: pd.DataFrame) -> np.ndarray:
        """Prepare features in exact same order as training"""
        # Validate all required columns exist
        for col in self.feature_columns:
            if col not in market_data.columns:
                raise ValueError(f"Missing required column: {col}")
        
        # Extract features in exact training order
        features = market_data[self.feature_columns].values
        
        # Handle any remaining NaN or infinite values
        features = np.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0)
        
        return features
    
    def _calculate_confidence(self, model_input: np.ndarray, predictions: np.ndarray) -> float:
        """Calculate prediction confidence based on model uncertainty"""
        try:
            # Simple confidence measure based on prediction variance
            # You can enhance this with more sophisticated uncertainty estimation
            
            # Make multiple predictions with slight input variations to estimate uncertainty
            confidences = []
            for _ in range(5):
                # Add small noise to input
                noisy_input = model_input + np.random.normal(0, 0.01, model_input.shape)
                pred = self.model.predict(noisy_input, verbose=0)[0]
                pred_unscaled = self.price_scaler.inverse_transform(pred.reshape(-1, 1)).flatten()
                
                # Calculate consistency with main prediction
                consistency = 1.0 - np.mean(np.abs(pred_unscaled - predictions) / predictions)
                confidences.append(max(0.0, consistency))
            
            confidence = np.mean(confidences)
            return float(min(1.0, max(0.0, confidence)))
            
        except Exception as e:
            logger.warning(f"Confidence calculation failed: {e}")
            return 0.5  # Default confidence
    
    def generate_multiple_predictions(self, market_data: pd.DataFrame, num_predictions: int = 5) -> List[dict]:
        """Generate multiple H1 predictions for analysis"""
        predictions = []
        
        for i in range(num_predictions):
            try:
                # Use slightly different data windows for variation
                start_idx = max(0, len(market_data) - self.sequence_length - i)
                end_idx = len(market_data) - i if i > 0 else len(market_data)
                
                data_window = market_data.iloc[start_idx:end_idx]
                
                if len(data_window) >= self.sequence_length:
                    h1_pred, pred_info = self.generate_h1_prediction(data_window)
                    pred_info['prediction_id'] = i
                    predictions.append(pred_info)
                    
            except Exception as e:
                logger.warning(f"Failed to generate prediction {i}: {e}")
        
        return predictions
    
    def save_prediction_to_file(self, prediction_info: dict, filename: str = None) -> str:
        """Save prediction to JSON file for MT5 integration"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"h1_prediction_{timestamp}.json"
        
        try:
            with open(filename, 'w') as f:
                json.dump(prediction_info, f, indent=2)
            
            logger.info(f"Prediction saved to: {filename}")
            return filename
            
        except Exception as e:
            logger.error(f"Failed to save prediction: {e}")
            raise

def load_market_data_from_csv(csv_file: str) -> pd.DataFrame:
    """Load market data from CSV file (MT5 export format)"""
    try:
        # Try common MT5 CSV formats
        df = pd.read_csv(csv_file)
        
        # Common column name mappings
        column_mappings = {
            'Open': 'open', 'High': 'high', 'Low': 'low', 'Close': 'close', 'Volume': 'volume',
            'OPEN': 'open', 'HIGH': 'high', 'LOW': 'low', 'CLOSE': 'close', 'VOLUME': 'volume'
        }
        
        df = df.rename(columns=column_mappings)
        
        # Ensure required columns exist
        required_cols = ['open', 'high', 'low', 'close', 'volume']
        for col in required_cols:
            if col not in df.columns:
                raise ValueError(f"Missing required column: {col}")
        
        return df[required_cols]
        
    except Exception as e:
        logger.error(f"Failed to load market data from {csv_file}: {e}")
        raise

def generate_sample_data(symbol: str = "EURUSD", bars: int = 100) -> pd.DataFrame:
    """Generate sample market data for testing"""
    logger.info(f"Generating {bars} bars of sample data for {symbol}")
    
    np.random.seed(42)
    
    # Start with realistic price
    start_price = 1.1650 if symbol == "EURUSD" else 1.0000
    
    ohlc_data = []
    current_price = start_price
    
    for i in range(bars):
        # Generate realistic price movement
        change = np.random.normal(0, 0.0005)  # Small realistic changes
        current_price += change
        current_price = max(0.5, min(2.0, current_price))  # Keep in reasonable range
        
        # Generate OHLC
        volatility = np.random.uniform(0.0002, 0.0008)
        open_price = current_price + np.random.normal(0, volatility/4)
        close_price = current_price + np.random.normal(0, volatility/4)
        
        high_price = max(open_price, close_price) + abs(np.random.normal(0, volatility/3))
        low_price = min(open_price, close_price) - abs(np.random.normal(0, volatility/3))
        
        volume = np.random.uniform(500, 5000)
        
        ohlc_data.append([open_price, high_price, low_price, close_price, volume])
    
    return np.array(ohlc_data)

def main():
    """Main function for testing the predictor"""
    logger.info("🚀 Real H1 Prediction Generator Starting...")
    
    # Initialize predictor
    predictor = RealH1Predictor()
    
    if not predictor.is_loaded:
        logger.error("❌ Failed to load trained model. Please run train_model.py first.")
        return
    
    # Test with sample data
    logger.info("📊 Generating sample market data for testing...")
    sample_ohlc = generate_sample_data("EURUSD", 100)
    
    # Create market data with technical indicators
    market_data = predictor.create_market_data_from_ohlc(sample_ohlc)
    
    # Generate H1 prediction
    logger.info("🎯 Generating H1 prediction...")
    try:
        h1_prediction, prediction_info = predictor.generate_h1_prediction(market_data)
        
        print("\n" + "="*60)
        print("🎯 H1 PREDICTION RESULTS")
        print("="*60)
        print(f"Current Price:    {prediction_info['current_price']:.5f}")
        print(f"H1 Prediction:    {prediction_info['h1_prediction']:.5f}")
        print(f"Change:           {prediction_info['change_percent']:+.3f}%")
        print(f"Direction:        {prediction_info['direction']}")
        print(f"Confidence:       {prediction_info['model_confidence']:.1%}")
        print()
        print("All Hourly Predictions:")
        for i, pred in enumerate(prediction_info['all_hourly_predictions'], 1):
            change = ((pred - prediction_info['current_price']) / prediction_info['current_price']) * 100
            print(f"  H{i}: {pred:.5f} ({change:+.2f}%)")
        print("="*60)
        
        # Save prediction to file
        filename = predictor.save_prediction_to_file(prediction_info)
        print(f"💾 Prediction saved to: {filename}")
        
        logger.info("✅ Test completed successfully!")
        
    except Exception as e:
        logger.error(f"❌ Prediction failed: {e}")
        raise

if __name__ == "__main__":
    main()