import numpy as np
import pandas as pd

# ------------------------- Utility funcs -------------------------

def _ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()

def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    up = (delta.clip(lower=0)).rolling(period).mean()
    down = (-delta.clip(upper=0)).rolling(period).mean()
    rs = up / (down + 1e-12)
    return 100 - (100 / (1 + rs))

def _macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    ema_fast = _ema(close, fast)
    ema_slow = _ema(close, slow)
    macd_line = ema_fast - ema_slow
    signal_line = _ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist

def _true_range(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low).abs(),
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)
    return tr

def _atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    tr = _true_range(high, low, close)
    return tr.rolling(period).mean()

def _stochastic(high: pd.Series, low: pd.Series, close: pd.Series, k: int = 14, d: int = 3):
    lowest_low = low.rolling(k).min()
    highest_high = high.rolling(k).max()
    k_val = 100 * (close - lowest_low) / (highest_high - lowest_low + 1e-12)
    d_val = k_val.rolling(d).mean()
    return k_val, d_val

def _bollinger(close: pd.Series, period: int = 20, dev: float = 2.0):
    ma = close.rolling(period).mean()
    std = close.rolling(period).std(ddof=0)
    upper = ma + dev * std
    lower = ma - dev * std
    return ma, upper, lower

# ------------------------- Main feature function -------------------------

def compute_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Input df must contain columns: ['open','high','low','close','volume']
    Returns df with the following additional columns (matching your EA order):
        'rsi','macd','ma_20','bb_upper','bb_lower','atr','stochastic'
    Plus extra robust features (returns, zscores, vol, range ratios).
    """
    df = df.copy()

    # Core indicators
    df['rsi'] = _rsi(df['close'], 14)
    macd_line, macd_signal, macd_hist = _macd(df['close'], 12, 26, 9)
    df['macd'] = macd_line  # maintain your original column list using macd_line
    ma20, bb_upper, bb_lower = _bollinger(df['close'], 20, 2.0)
    df['ma_20'] = ma20
    df['bb_upper'] = bb_upper
    df['bb_lower'] = bb_lower
    df['atr'] = _atr(df['high'], df['low'], df['close'], 14)
    k, d = _stochastic(df['high'], df['low'], df['close'], 14, 3)
    df['stochastic'] = k

    # Extra robustness features (optional but helpful)
    df['ret_1'] = df['close'].pct_change()
    df['log_ret_1'] = np.log(df['close']).diff()
    df['hl_range'] = (df['high'] - df['low']) / (df['close'].shift(1) + 1e-12)
    df['body'] = (df['close'] - df['open']) / (df['open'] + 1e-12)
    df['vol_z'] = (df['volume'] - df['volume'].rolling(64).mean()) / (df['volume'].rolling(64).std(ddof=0) + 1e-12)
    df['rv_20'] = df['log_ret_1'].rolling(20).std(ddof=0)

    # Clean
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    df.dropna(inplace=True)

    return df

def ensure_column_order(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure the model-required column order used by the EA & trainer.
    """
    required = [
        'open','high','low','close','volume',
        'rsi','macd','ma_20','bb_upper','bb_lower','atr','stochastic'
    ]
    for col in required:
        if col not in df.columns:
            raise ValueError(f"Missing feature column: {col}")
    return df[required]
'''

data_mt5_fetch_py = r'''#!/usr/bin/env python3
"""
data_mt5_fetch.py
Fetch EURUSD H1 data from MetaTrader 5 or load from CSV.
- If MT5 is available, prefers MT5.
- If not, expects a CSV with columns: timestamp, open, high, low, close, volume
Outputs a cleaned CSV ready for feature engineering.
"""

import argparse
from datetime import datetime
import pandas as pd
from pathlib import Path

def try_mt5(symbol: str, start: str, end: str, timeframe: str = "H1", max_bars: int = 200000):
    try:
        import MetaTrader5 as mt5
    except Exception as e:
        print(f"[info] MetaTrader5 module not available: {e}")
        return None

    tf_map = {
        "M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15,
        "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1, "H4": mt5.TIMEFRAME_H4, "D1": mt5.TIMEFRAME_D1
    }
    if timeframe not in tf_map:
        raise ValueError("Unsupported timeframe: " + timeframe)

    if not mt5.initialize():
        print("[warn] MT5 initialize() failed; falling back to CSV.")
        return None

    try:
        sd = datetime.fromisoformat(start)
        ed = datetime.fromisoformat(end)
        rates = mt5.copy_rates_range(symbol, tf_map[timeframe], sd, ed)
        if rates is None or len(rates) == 0:
            print("[warn] MT5 returned no rates; falling back to CSV.")
            return None
        import numpy as np
        df = pd.DataFrame(rates)
        df['timestamp'] = pd.to_datetime(df['time'], unit='s')
        df.rename(columns={'tick_volume':'volume'}, inplace=True)
        df = df[['timestamp','open','high','low','close','volume']]
        df.sort_values('timestamp', inplace=True)
        return df
    finally:
        mt5.shutdown()

def load_csv(csv_path: str):
    p = Path(csv_path)
    if not p.exists():
        raise FileNotFoundError(f"CSV not found at {csv_path}")
    df = pd.read_csv(p)
    if 'timestamp' not in df.columns:
        raise ValueError("CSV must contain 'timestamp' column")
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    cols = ['open','high','low','close','volume']
    for c in cols:
        if c not in df.columns:
            raise ValueError(f"CSV missing required column: {c}")
    df = df[['timestamp'] + cols]
    df.sort_values('timestamp', inplace=True)
    return df

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--symbol', default='EURUSD')
    ap.add_argument('--timeframe', default='H1')
    ap.add_argument('--start', required=True, help='ISO date, e.g., 2015-01-01')
    ap.add_argument('--end', required=True, help='ISO date, e.g., 2025-08-01')
    ap.add_argument('--csv_fallback', default='', help='Path to CSV if MT5 not available')
    ap.add_argument('--out', default='EURUSD_H1_raw.csv')
    args = ap.parse_args()

    df = try_mt5(args.symbol, args.start, args.end, args.timeframe)
    if df is None:
        if not args.csv_fallback:
            raise SystemExit("MT5 unavailable and no CSV provided. Supply --csv_fallback path.")
        df = load_csv(args.csv_fallback)

    df.to_csv(args.out, index=False)
    print(f"[ok] Saved raw data to {args.out} with {len(df)} rows.")

if __name__ == '__main__':
    main()