import argparse
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib
from tensorflow.keras.models import load_model

# FIX: Import the corrected, single source of truth for custom layers
from model_attn_transformer import TemporalAttention, PositionalEncoding, TransformerBlock
from features import compute_features

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--raw_csv', default='EURUSD_H1_raw.csv')
    ap.add_argument('--model_dir', default='models_EURUSD_H1_plus')
    ap.add_argument('--test_bars', type=int, default=1000)
    args = ap.parse_args()

    model_dir = Path(args.model_dir)
    cfg = json.loads((model_dir / 'model_config.json').read_text(encoding='utf-8'))
    
    # Extract config parameters
    seq_len = cfg['sequence_length']
    pred_steps = cfg['prediction_steps']
    feature_cols = cfg['feature_columns']
    
    # FIX: Pass the imported classes to custom_objects for correct model loading.
    custom_objects = {
        'TemporalAttention': TemporalAttention,
        'PositionalEncoding': PositionalEncoding,
        'TransformerBlock': TransformerBlock,
        'loss': lambda y_true, y_pred: 0.0 # Dummy loss for inference
    }
    model = load_model(model_dir / 'best_attention_plus_model.h5',
                       custom_objects=custom_objects,
                       compile=False)
    
    feat_scaler = joblib.load(model_dir / 'feature_scaler.pkl')
    price_scaler = joblib.load(model_dir / 'price_scaler.pkl')
    
    df_raw = pd.read_csv(args.raw_csv, parse_dates=['timestamp']).set_index('timestamp')
    df_feat = compute_features(df_raw)

    # Ensure all feature columns from training are present, filling with 0 if needed
    for c in feature_cols:
        if c not in df_feat.columns:
            df_feat[c] = 0.0
    df_feat_full = df_feat[feature_cols].dropna()

    # Use tail for evaluation
    df_eval = df_feat_full.iloc[-(args.test_bars + seq_len + pred_steps + 10):].copy()

    feats_scaled = feat_scaler.transform(df_eval.values)
    closes = df_eval['close'].values

    X, y_actual, y_indices = [], [], []
    for i in range(seq_len, len(feats_scaled) - pred_steps):
        X.append(feats_scaled[i-seq_len:i])
        y_actual.append(closes[i : i+pred_steps])
        y_indices.append(df_eval.index[i])
    
    X = np.array(X)
    y_actual = np.array(y_actual)

    pred_scaled = model.predict(X, verbose=1)
    pred = price_scaler.inverse_transform(pred_scaled)

    # Create a DataFrame for easier analysis and plotting
    df_results = pd.DataFrame(index=y_indices)
    df_results['actual_h1'] = y_actual[:, 0]
    df_results['pred_h1'] = pred[:, 0]
    
    # Visualize t+1
    plt.figure(figsize=(15, 7))
    plt.plot(df_results['actual_h1'][-200:], label='Actual Close (t+1)', color='blue', alpha=0.8)
    plt.plot(df_results['pred_h1'][-200:], label='Predicted Close (t+1)', color='orange', linestyle='--')
    plt.title(f'{Path(args.raw_csv).stem}: t+1 Predictions (last 200 samples)')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    out_png = model_dir / 'evaluation_plus_h1_last200.png'
    plt.savefig(out_png, dpi=150)
    print(f"[ok] Saved plot: {out_png}")

if __name__ == '__main__':
    main()