import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import logging
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, models, optimizers, callbacks

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --------------------------- Data Generator ---------------------------

class CorrectedForexDataGenerator:
    """Generate realistic forex data with proper scaling"""
    def __init__(self, symbol="EURUSD", start_price=1.1650):
        self.symbol = symbol
        self.start_price = start_price

    def generate_realistic_data(self, n_bars=10000) -> pd.DataFrame:
        """Generate realistic forex price movements with PROPER scaling"""
        logger.info(f"Generating {n_bars} bars of PROPERLY SCALED data for {self.symbol}")

        np.random.seed(42)

        data = []
        current_price = self.start_price  # Start with realistic EURUSD price

        for i in range(n_bars):
            # Realistic forex price movements
            trend = np.random.normal(0, 0.00005)      # Very small trend
            volatility = np.random.uniform(0.0002, 0.0008)

            # Price change
            change = np.random.normal(trend, volatility)
            current_price += change
            current_price = max(0.9500, min(1.3000, current_price))

            # Generate OHLC
            spread = np.random.uniform(0.00008, 0.00015)
            open_price = current_price + np.random.normal(0, volatility/4)

            high_offset = abs(np.random.normal(0, volatility/3))
            low_offset = abs(np.random.normal(0, volatility/3))

            high_price = current_price + high_offset
            low_price = current_price - low_offset
            close_price = current_price + np.random.normal(0, volatility/4)

            # Ensure OHLC consistency and bounds
            high_price = max(high_price, open_price, close_price)
            low_price = min(low_price, open_price, close_price)
            open_price = max(0.9500, min(1.3000, open_price))
            high_price = max(0.9500, min(1.3000, high_price))
            low_price = max(0.9500, min(1.3000, low_price))
            close_price = max(0.9500, min(1.3000, close_price))

            # Volume and indicators
            volume = np.random.uniform(500, 5000)
            rsi = np.random.uniform(20, 80)
            macd = np.random.normal(0, 0.00005)
            ma_20 = close_price + np.random.normal(0, 0.0001)
            bb_upper = close_price + (volatility * 2)
            bb_lower = close_price - (volatility * 2)
            atr = volatility * 10000
            stochastic = np.random.uniform(10, 90)

            timestamp = datetime.now() - timedelta(hours=n_bars-i)

            data.append({
                'timestamp': timestamp,
                'open': open_price,
                'high': high_price,
                'low': low_price,
                'close': close_price,
                'volume': volume,
                'rsi': rsi,
                'macd': macd,
                'ma_20': ma_20,
                'bb_upper': bb_upper,
                'bb_lower': bb_lower,
                'atr': atr,
                'stochastic': stochastic
            })

            current_price = close_price

        df = pd.DataFrame(data)
        df.set_index('timestamp', inplace=True)

        # Validation checks
        logger.info("Generated data validation:")
        logger.info(f"  Close price range: [{df['close'].min():.5f}, {df['close'].max():.5f}]")
        logger.info(f"  Close price mean: {df['close'].mean():.5f}")
        logger.info(f"  RSI range: [{df['rsi'].min():.1f}, {df['rsi'].max():.1f}]")
        logger.info(f"  MACD range: [{df['macd'].min():.6f}, {df['macd'].max():.6f}]")
        logger.info(f"  Volume range: [{df['volume'].min():.0f}, {df['volume'].max():.0f}]")
        return df

# --------------------------- Attention Layer ---------------------------

class TemporalAttention(layers.Layer):
    """
    Simple additive (Bahdanau-style) temporal attention.
    Given sequence H (batch, T, F), returns context (batch, F).
    Stores last attention weights in self.last_attention for inspection.
    """
    def __init__(self, attn_units: int = 64, **kwargs):
        super().__init__(**kwargs)
        self.attn_units = attn_units
        self.W = layers.Dense(attn_units)
        self.V = layers.Dense(1)
        self.last_attention = None  # (batch, T, 1)

    def call(self, inputs):
        # inputs: (batch, timesteps, features)
        # score: (batch, timesteps, 1)
        score = self.V(tf.nn.tanh(self.W(inputs)))
        weights = tf.nn.softmax(score, axis=1)  # attention over timesteps
        self.last_attention = weights
        context = tf.reduce_sum(weights * inputs, axis=1)  # (batch, features)
        return context

    def get_config(self):
        cfg = super().get_config()
        cfg.update({"attn_units": self.attn_units})
        return cfg

# --------------------------- Trainer ---------------------------

class CorrectedLSTMAttnCNNTrainer:
    """LSTM+CNN Model Trainer with temporal attention and CORRECTED scaling"""

    def __init__(self, sequence_length=60, n_features=12, prediction_steps=5, attn_units=64):
        self.sequence_length = sequence_length
        self.n_features = n_features
        self.prediction_steps = prediction_steps
        self.attn_units = attn_units
        self.model = None

        # Use MinMaxScaler for both features and prices
        self.price_scaler = MinMaxScaler(feature_range=(0, 1))
        self.feature_scaler = MinMaxScaler(feature_range=(0, 1))

        self.is_trained = False

    def prepare_features(self, df: pd.DataFrame) -> np.ndarray:
        """Prepare feature matrix - EXACT same order as MQL5 EA"""
        logger.info("Preparing features with CORRECTED scaling...")

        feature_columns = [
            'open', 'high', 'low', 'close', 'volume',
            'rsi', 'macd', 'ma_20', 'bb_upper', 'bb_lower', 'atr', 'stochastic'
        ]
        for col in feature_columns:
            if col not in df.columns:
                raise ValueError(f"Missing feature column: {col}")

        features = df[feature_columns].values

        # Log ranges before scaling
        logger.info("Feature ranges BEFORE scaling:")
        for i, col in enumerate(feature_columns):
            logger.info(f"  {col}: [{features[:, i].min():.6f}, {features[:, i].max():.6f}]")

        features = np.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0)
        return features

    def create_sequences(self, features: np.ndarray, target_prices: np.ndarray) -> tuple:
        """Create sequences for LSTM training"""
        logger.info("Creating sequences...")
        X, y = [], []
        for i in range(self.sequence_length, len(features) - self.prediction_steps):
            X.append(features[i-self.sequence_length:i])
            y.append(target_prices[i:i+self.prediction_steps])  # next steps
        X = np.array(X)
        y = np.array(y)
        logger.info(f"Sequence shapes - X: {X.shape}, y: {y.shape}")
        return X, y

    def build_model(self) -> None:
        """Build Attention-augmented LSTM+CNN model"""
        logger.info("Building ATTENTION-BASED LSTM+CNN model...")

        inputs = layers.Input(shape=(self.sequence_length, self.n_features))

        # --- CNN feature extractor over time ---
        x = layers.Conv1D(64, 3, activation='relu', padding='causal')(inputs)
        x = layers.BatchNormalization()(x)
        x = layers.Conv1D(64, 3, activation='relu', padding='causal')(x)
        x = layers.MaxPooling1D(pool_size=2)(x)
        x = layers.Dropout(0.2)(x)

        x = layers.Conv1D(50, 3, activation='relu', padding='causal')(x)
        x = layers.BatchNormalization()(x)
        x = layers.Conv1D(50, 3, activation='relu', padding='causal')(x)
        x = layers.MaxPooling1D(pool_size=2)(x)
        x = layers.Dropout(0.2)(x)

        # --- LSTM for temporal dependencies ---
        # Return sequences for attention to have time dimension
        x = layers.LSTM(128, return_sequences=True)(x)
        x = layers.Dropout(0.3)(x)

        # --- Temporal Attention ---
        context = TemporalAttention(attn_units=self.attn_units, name="temporal_attention")(x)

        # --- Dense head ---
        x = layers.Dense(64, activation='relu')(context)
        x = layers.BatchNormalization()(x)
        x = layers.Dropout(0.2)(x)
        x = layers.Dense(32, activation='relu')(x)
        outputs = layers.Dense(self.prediction_steps, name="predictions")(x)

        self.model = keras.Model(inputs=inputs, outputs=outputs, name="LSTM_CNN_Attention")

        self.model.compile(
            optimizer=optimizers.Adam(learning_rate=0.001),
            loss='mse',
            metrics=['mae']
        )

        logger.info(f"Model built with {self.model.count_params()} parameters")
        self.model.summary(print_fn=lambda s: logger.info(s))

    def train(self, df: pd.DataFrame, validation_split=0.2, epochs=50, batch_size=32):
        """Train the model with CORRECTED scaling and temporal attention"""
        logger.info("Starting ATTENTION-BASED model training...")

        # Prepare features
        features = self.prepare_features(df)
        target_prices = df['close'].values.reshape(-1, 1)

        logger.info("SCALING DATA CORRECTLY...")
        features_scaled = self.feature_scaler.fit_transform(features)
        target_scaled = self.price_scaler.fit_transform(target_prices).flatten()

        # Round-trip test
        test_price = np.array([[1.1650]])
        test_scaled = self.price_scaler.transform(test_price)
        test_unscaled = self.price_scaler.inverse_transform(test_scaled)
        logger.info(f"  Round-trip test: {test_price[0][0]:.5f} -> {test_scaled[0][0]:.5f} -> {test_unscaled[0][0]:.5f}")

        # Sequences
        X, y = self.create_sequences(features_scaled, target_scaled)
        if len(X) == 0:
            raise ValueError("No sequences created")

        # Build model if needed
        if self.model is None:
            self.build_model()

        # Callbacks
        callbacks_list = [
            callbacks.EarlyStopping(patience=10, restore_best_weights=True),
            callbacks.ReduceLROnPlateau(factor=0.5, patience=5),
            callbacks.ModelCheckpoint('best_model_attention.h5', save_best_only=True)
        ]

        # Train
        history = self.model.fit(
            X, y,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=validation_split,
            callbacks=callbacks_list,
            verbose=1,
            shuffle=True
        )

        self.is_trained = True

        # Quick post-train sanity check on scaling
        self._test_prediction_scaling(X, target_prices)

        return history

    def _test_prediction_scaling(self, X, original_prices):
        """Test that predictions are in the right scale"""
        logger.info("Testing prediction scaling...")
        test_pred_scaled = self.model.predict(X[:1], verbose=0)
        test_pred_unscaled = self.price_scaler.inverse_transform(test_pred_scaled)[0]
        current_price = float(original_prices[-1][0])
        logger.info("Scaling test results:")
        logger.info(f"  Current price: {current_price:.5f}")
        for i, pred in enumerate(test_pred_unscaled):
            change_pct = ((pred - current_price) / current_price) * 100.0
            logger.info(f"    Step {i+1}: {pred:.5f} ({change_pct:+.2f}%)")
            if abs(change_pct) > 50:
                logger.warning("    ⚠️  Potentially unrealistic prediction!")

    def save_model(self, filepath='lstm_cnn_attention_model.h5'):
        """Save the model and scalers"""
        if not self.is_trained:
            raise ValueError("Model not trained yet")

        self.model.save(filepath)
        joblib.dump(self.price_scaler, 'price_scaler.pkl')
        joblib.dump(self.feature_scaler, 'feature_scaler.pkl')

        config = {
            'sequence_length': self.sequence_length,
            'n_features': self.n_features,
            'prediction_steps': self.prediction_steps,
            'attn_units': self.attn_units,
            'price_scaler_info': {
                'min_': self.price_scaler.min_.tolist(),
                'scale_': self.price_scaler.scale_.tolist(),
                'data_min_': self.price_scaler.data_min_.tolist(),
                'data_max_': self.price_scaler.data_max_.tolist(),
                'feature_range': self.price_scaler.feature_range
            },
            'feature_scaler_info': {
                'min_': self.feature_scaler.min_.tolist(),
                'scale_': self.feature_scaler.scale_.tolist(),
                'n_features_in_': int(self.feature_scaler.n_features_in_),
                'feature_range': self.feature_scaler.feature_range
            }
        }
        with open('model_config_attention.json', 'w') as f:
            json.dump(config, f, indent=2)

        logger.info(f"ATTENTION model saved to {filepath}")
        logger.info("Scaler information saved to model_config_attention.json")

# --------------------------- Main ---------------------------

def main():
    logger.info("Starting ATTENTION-BASED LSTM+CNN training...")
    generator = CorrectedForexDataGenerator("EURUSD", start_price=1.1650)
    df = generator.generate_realistic_data(10000)

    trainer = CorrectedLSTMAttnCNNTrainer(
        sequence_length=60,
        n_features=12,
        prediction_steps=5,
        attn_units=64
    )

    try:
        history = trainer.train(df, epochs=50, batch_size=32)
        trainer.save_model()
        logger.info("ATTENTION training completed successfully!")
    except Exception as e:
        logger.error(f"Training failed: {str(e)}")
        raise

if __name__ == '__main__':
    main()
