import argparse
from datetime import datetime
import pandas as pd
from pathlib import Path

def try_mt5(symbol: str, start: str, end: str, timeframe: str = "H1"): # FIX: Removed unused max_bars argument
    try:
        import MetaTrader5 as mt5
    except Exception as e:
        print(f"[info] MetaTrader5 module not available: {e}")
        return None

    tf_map = {
        "M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15,
        "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1, "H4": mt5.TIMEFRAME_H4, "D1": mt5.TIMEFRAME_D1
    }
    if timeframe not in tf_map:
        raise ValueError("Unsupported timeframe: " + timeframe)

    if not mt5.initialize():
        print("[warn] MT5 initialize() failed; falling back to CSV.")
        return None

    try:
        sd = datetime.fromisoformat(start)
        ed = datetime.fromisoformat(end)
        rates = mt5.copy_rates_range(symbol, tf_map[timeframe], sd, ed)
        if rates is None or len(rates) == 0:
            print("[warn] MT5 returned no rates; falling back to CSV.")
            return None
        
        df = pd.DataFrame(rates)
        df['timestamp'] = pd.to_datetime(df['time'], unit='s')
        df.rename(columns={'tick_volume':'volume'}, inplace=True)
        df = df[['timestamp','open','high','low','close','volume']]
        df.sort_values('timestamp', inplace=True)
        return df
    finally:
        mt5.shutdown()

def load_csv(csv_path: str):
    p = Path(csv_path)
    if not p.exists():
        raise FileNotFoundError(f"CSV not found at {csv_path}")
    df = pd.read_csv(p)
    if 'timestamp' not in df.columns:
        raise ValueError("CSV must contain 'timestamp' column")
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    cols = ['open','high','low','close','volume']
    for c in cols:
        if c not in df.columns:
            raise ValueError(f"CSV missing required column: {c}")
    df = df[['timestamp'] + cols]
    df.sort_values('timestamp', inplace=True)
    return df

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--symbol', default='EURUSD')
    ap.add_argument('--timeframe', default='H1')
    ap.add_argument('--start', required=True, help='ISO date, e.g., 2015-01-01')
    ap.add_argument('--end', required=True, help='ISO date, e.g., 2025-08-01')
    ap.add_argument('--csv_fallback', default='', help='Path to CSV if MT5 not available')
    ap.add_argument('--out', default='EURUSD_H1_raw.csv')
    args = ap.parse_args()

    df = try_mt5(args.symbol, args.start, args.end, args.timeframe)
    if df is None:
        if not args.csv_fallback:
            raise SystemExit("MT5 unavailable and no CSV provided. Supply --csv_fallback path.")
        df = load_csv(args.csv_fallback)

    df.to_csv(args.out, index=False)
    print(f"[ok] Saved raw data to {args.out} with {len(df)} rows.")

if __name__ == '__main__':
    main()