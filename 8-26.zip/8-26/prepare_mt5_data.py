#!/usr/bin/env python3
"""
MT5 Data Preparation Script for EA Training
Fetches and prepares historical OHLCV data from MetaTrader 5
"""

import MetaTrader5 as mt5
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from pathlib import Path
import argparse
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def initialize_mt5():
    """Initialize MT5 connection"""
    if not mt5.initialize():
        logger.error("MT5 initialization failed")
        print(f"Error: {mt5.last_error()}")
        return False
    
    logger.info(f"MT5 initialized successfully")
    logger.info(f"MT5 version: {mt5.version()}")
    logger.info(f"Account info: {mt5.account_info()._asdict()}")
    return True

def fetch_historical_data(symbol: str, timeframe: str, num_bars: int = 50000) -> pd.DataFrame:
    """
    Fetch historical OHLCV data from MT5
    
    Args:
        symbol: Trading symbol (e.g., 'EURUSD')
        timeframe: Timeframe (e.g., 'H1', 'M15', 'D1')
        num_bars: Number of bars to fetch
    
    Returns:
        DataFrame with OHLCV data
    """
    # Map timeframe strings to MT5 constants
    timeframe_map = {
        'M1': mt5.TIMEFRAME_M1,
        'M5': mt5.TIMEFRAME_M5,
        'M15': mt5.TIMEFRAME_M15,
        'M30': mt5.TIMEFRAME_M30,
        'H1': mt5.TIMEFRAME_H1,
        'H4': mt5.TIMEFRAME_H4,
        'D1': mt5.TIMEFRAME_D1,
        'W1': mt5.TIMEFRAME_W1,
        'MN1': mt5.TIMEFRAME_MN1
    }
    
    if timeframe not in timeframe_map:
        raise ValueError(f"Unsupported timeframe: {timeframe}. Use: {list(timeframe_map.keys())}")
    
    mt5_timeframe = timeframe_map[timeframe]
    
    # Fetch data
    logger.info(f"Fetching {num_bars} bars of {symbol} {timeframe} data...")
    rates = mt5.copy_rates_from_pos(symbol, mt5_timeframe, 0, num_bars)
    
    if rates is None:
        logger.error(f"Failed to fetch data for {symbol}")
        print(f"Error: {mt5.last_error()}")
        return None
    
    # Convert to DataFrame
    df = pd.DataFrame(rates)
    df['timestamp'] = pd.to_datetime(df['time'], unit='s')
    df = df.drop(['time', 'spread', 'real_volume'], axis=1, errors='ignore')
    df = df[['timestamp', 'open', 'high', 'low', 'close', 'tick_volume']]
    df.rename(columns={'tick_volume': 'volume'}, inplace=True)
    df.set_index('timestamp', inplace=True)
    
    logger.info(f"Successfully fetched {len(df)} bars")
    logger.info(f"Date range: {df.index[0]} to {df.index[-1]}")
    logger.info(f"Price range: {df['close'].min():.5f} - {df['close'].max():.5f}")
    
    return df

def validate_data_quality(df: pd.DataFrame) -> bool:
    """Validate the quality of fetched data"""
    logger.info("Validating data quality...")
    
    issues = []
    
    # Check for missing values
    missing_values = df.isnull().sum()
    if missing_values.any():
        issues.append(f"Missing values found: {missing_values.to_dict()}")
    
    # Check for zero or negative prices
    price_columns = ['open', 'high', 'low', 'close']
    for col in price_columns:
        if (df[col] <= 0).any():
            issues.append(f"Zero or negative prices found in {col}")
    
    # Check for invalid OHLC relationships
    invalid_ohlc = (
        (df['high'] < df['open']) | 
        (df['high'] < df['close']) | 
        (df['low'] > df['open']) | 
        (df['low'] > df['close']) |
        (df['high'] < df['low'])
    )
    if invalid_ohlc.any():
        issues.append(f"Invalid OHLC relationships found in {invalid_ohlc.sum()} bars")
    
    # Check for extreme price movements (more than 10% in one bar)
    price_changes = df['close'].pct_change().abs()
    extreme_moves = price_changes > 0.10
    if extreme_moves.any():
        issues.append(f"Extreme price movements (>10%) found in {extreme_moves.sum()} bars")
    
    # Check for zero volume
    zero_volume = df['volume'] == 0
    if zero_volume.any():
        issues.append(f"Zero volume found in {zero_volume.sum()} bars")
    
    # Check for gaps in time series
    expected_freq = pd.infer_freq(df.index[:100])  # Infer from first 100 bars
    if expected_freq:
        expected_index = pd.date_range(start=df.index[0], end=df.index[-1], freq=expected_freq)
        missing_timestamps = len(expected_index) - len(df)
        if missing_timestamps > len(df) * 0.05:  # More than 5% missing
            issues.append(f"Significant gaps in time series: {missing_timestamps} missing periods")
    
    if issues:
        logger.warning("Data quality issues found:")
        for issue in issues:
            logger.warning(f"  - {issue}")
        return False
    else:
        logger.info("Data quality validation passed")
        return True

def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and prepare data for training"""
    logger.info("Cleaning data...")
    
    initial_len = len(df)
    
    # Remove rows with missing values
    df = df.dropna()
    
    # Remove rows with zero or negative prices
    price_columns = ['open', 'high', 'low', 'close']
    for col in price_columns:
        df = df[df[col] > 0]
    
    # Remove rows with invalid OHLC relationships
    valid_ohlc = (
        (df['high'] >= df['open']) & 
        (df['high'] >= df['close']) & 
        (df['low'] <= df['open']) & 
        (df['low'] <= df['close']) &
        (df['high'] >= df['low'])
    )
    df = df[valid_ohlc]
    
    # Remove extreme outliers (more than 5 standard deviations from mean)
    for col in price_columns:
        mean = df[col].mean()
        std = df[col].std()
        df = df[abs(df[col] - mean) <= 5 * std]
    
    # Ensure volume is positive
    df = df[df['volume'] > 0]
    
    # Sort by timestamp to ensure chronological order
    df = df.sort_index()
    
    cleaned_len = len(df)
    removed_rows = initial_len - cleaned_len
    
    logger.info(f"Data cleaning completed:")
    logger.info(f"  - Initial rows: {initial_len}")
    logger.info(f"  - Cleaned rows: {cleaned_len}")
    logger.info(f"  - Removed rows: {removed_rows} ({removed_rows/initial_len*100:.2f}%)")
    
    return df

def save_data(df: pd.DataFrame, output_path: Path, symbol: str, timeframe: str):
    """Save processed data to CSV"""
    logger.info(f"Saving data to {output_path}")
    
    # Reset index to include timestamp as column
    df_save = df.reset_index()
    
    # Save to CSV
    df_save.to_csv(output_path, index=False)
    
    # Create summary file
    summary_path = output_path.parent / f"{output_path.stem}_summary.txt"
    with open(summary_path, 'w') as f:
        f.write(f"Data Summary for {symbol} {timeframe}\n")
        f.write("=" * 50 + "\n")
        f.write(f"Total bars: {len(df)}\n")
        f.write(f"Date range: {df.index[0]} to {df.index[-1]}\n")
        f.write(f"Duration: {df.index[-1] - df.index[0]}\n")
        f.write(f"Price range: {df['close'].min():.5f} - {df['close'].max():.5f}\n")
        f.write(f"Average volume: {df['volume'].mean():.0f}\n")
        f.write("\nPrice Statistics:\n")
        f.write(df[['open', 'high', 'low', 'close']].describe().to_string())
        f.write(f"\n\nVolume Statistics:\n")
        f.write(df['volume'].describe().to_string())
    
    logger.info(f"Data saved successfully:")
    logger.info(f"  - CSV file: {output_path}")
    logger.info(f"  - Summary: {summary_path}")

def main():
    parser = argparse.ArgumentParser(description='Prepare MT5 data for EA training')
    parser.add_argument('--symbol', type=str, default='EURUSD',
                       help='Trading symbol')
    parser.add_argument('--timeframe', type=str, default='H1',
                       choices=['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1', 'W1', 'MN1'],
                       help='Timeframe')
    parser.add_argument('--num_bars', type=int, default=50000,
                       help='Number of bars to fetch')
    parser.add_argument('--output_dir', type=str, default='data',
                       help='Output directory')
    parser.add_argument('--validate', action='store_true',
                       help='Perform data quality validation')
    parser.add_argument('--clean', action='store_true', default=True,
                       help='Clean data before saving')
    
    args = parser.parse_args()
    
    # Setup output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Initialize MT5
    if not initialize_mt5():
        return
    
    try:
        # Fetch data
        df = fetch_historical_data(args.symbol, args.timeframe, args.num_bars)
        if df is None:
            return
        
        # Validate data quality
        if args.validate:
            validate_data_quality(df)
        
        # Clean data
        if args.clean:
            df = clean_data(df)
        
        # Save data
        output_filename = f"{args.symbol}_{args.timeframe}_raw.csv"
        output_path = output_dir / output_filename
        save_data(df, output_path, args.symbol, args.timeframe)
        
        logger.info("=" * 60)
        logger.info("DATA PREPARATION COMPLETED SUCCESSFULLY")
        logger.info("=" * 60)
        logger.info(f"Symbol: {args.symbol}")
        logger.info(f"Timeframe: {args.timeframe}")
        logger.info(f"Total bars: {len(df)}")
        logger.info(f"Output file: {output_path}")
        logger.info("\nNext steps:")
        logger.info("1. Review the data summary file")
        logger.info("2. Run the complete training script:")
        logger.info(f"   python complete_ea_training.py --data_path {output_path}")
        
    except Exception as e:
        logger.error(f"Error during data preparation: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Shutdown MT5
        mt5.shutdown()
        logger.info("MT5 connection closed")

if __name__ == '__main__':
    main()