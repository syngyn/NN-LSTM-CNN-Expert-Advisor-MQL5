import argparse
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import load_model
from tensorflow.keras import layers
import joblib
from features import compute_features, ensure_column_order
import tensorflow as tf

class TemporalAttention(layers.Layer):
    def __init__(self, attn_units: int = 64, **kwargs):
        super().__init__(**kwargs)
        self.attn_units = attn_units
        self.W = layers.Dense(attn_units)
        self.V = layers.Dense(1)
    def call(self, inputs):
        score = self.V(tf.nn.tanh(self.W(inputs)))
        weights = tf.nn.softmax(score, axis=1)
        context = tf.reduce_sum(weights * inputs, axis=1)
        return context
    def get_config(self):
        cfg = super().get_config()
        cfg.update({"attn_units": self.attn_units})
        return cfg

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--raw_csv', default='EURUSD_H1_raw.csv')
    ap.add_argument('--model_dir', default='models_EURUSD_H1')
    ap.add_argument('--seq_len', type=int, default=128)
    ap.add_argument('--pred_steps', type=int, default=5)
    ap.add_argument('--test_bars', type=int, default=1000)
    args = ap.parse_args()

    model_dir = Path(args.model_dir)
    model = load_model(model_dir / 'best_attention_model.h5', custom_objects={'TemporalAttention': TemporalAttention})
    feat_scaler = joblib.load(model_dir / 'feature_scaler.pkl')
    price_scaler = joblib.load(model_dir / 'price_scaler.pkl')

    df_raw = pd.read_csv(args.raw_csv, parse_dates=['timestamp']).set_index('timestamp')
    df_raw = df_raw[['open','high','low','close','volume']]
    df_feat = compute_features(df_raw)
    df_feat = ensure_column_order(df_feat)

    # Use the last test_bars for evaluation
    df_eval = df_feat.iloc[-(args.test_bars + args.seq_len + args.pred_steps + 10):].copy()

    feats = feat_scaler.transform(df_eval.values)
    closes = df_eval['close'].values.reshape(-1,1)

    X, y = [], []
    for i in range(args.seq_len, len(feats) - args.pred_steps):
        X.append(feats[i-args.seq_len:i])
        y.append(closes[i:i+args.pred_steps])
    X = np.array(X); y = np.array(y).reshape(-1, args.pred_steps)

    pred_scaled = model.predict(X, verbose=0)
    pred = price_scaler.inverse_transform(pred_scaled)

    # Plot last 200 predictions of horizon 1 vs actual
    horizon = 1
    actual_h1 = y[:, horizon-1].flatten()
    pred_h1 = pred[:, horizon-1].flatten()

    plt.figure(figsize=(12,5))
    plt.plot(actual_h1[-200:], label='Actual Close (t+1)')
    plt.plot(pred_h1[-200:], label='Predicted Close (t+1)')
    plt.title('EURUSD H1: t+1 Predictions (last 200 samples)')
    plt.legend()
    plt.tight_layout()
    out_png = model_dir / 'evaluation_h1_last200.png'
    plt.savefig(out_png, dpi=150)
    print(f"[ok] Saved plot: {out_png}")

if __name__ == '__main__':
    main()