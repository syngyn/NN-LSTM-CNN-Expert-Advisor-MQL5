import numpy as np
import pandas as pd
from typing import Optional


def compute_rsi(prices: pd.Series, period: int = 14) -> pd.Series:
    """Compute RSI (Relative Strength Index)"""
    delta = prices.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi


def compute_macd(prices: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> tuple:
    """Compute MACD (Moving Average Convergence Divergence)"""
    ema_fast = prices.ewm(span=fast).mean()
    ema_slow = prices.ewm(span=slow).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal).mean()
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


def compute_bollinger_bands(prices: pd.Series, period: int = 20, std_dev: float = 2.0) -> tuple:
    """Compute Bollinger Bands"""
    ma = prices.rolling(window=period).mean()
    std = prices.rolling(window=period).std()
    upper_band = ma + (std * std_dev)
    lower_band = ma - (std * std_dev)
    return upper_band, lower_band, ma


def compute_atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    """Compute Average True Range (ATR)"""
    high_low = high - low
    high_close = np.abs(high - close.shift())
    low_close = np.abs(low - close.shift())
    
    true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    atr = true_range.rolling(window=period).mean()
    return atr


def compute_stochastic(high: pd.Series, low: pd.Series, close: pd.Series, k_period: int = 14, d_period: int = 3) -> tuple:
    """Compute Stochastic Oscillator"""
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()
    
    k_percent = 100 * ((close - lowest_low) / (highest_high - lowest_low))
    d_percent = k_percent.rolling(window=d_period).mean()
    
    return k_percent, d_percent


def compute_moving_average(prices: pd.Series, period: int = 20) -> pd.Series:
    """Compute Simple Moving Average"""
    return prices.rolling(window=period).mean()


def compute_ema(prices: pd.Series, period: int = 20) -> pd.Series:
    """Compute Exponential Moving Average"""
    return prices.ewm(span=period).mean()


def compute_momentum(prices: pd.Series, period: int = 10) -> pd.Series:
    """Compute Price Momentum"""
    return prices.diff(period)


def compute_roc(prices: pd.Series, period: int = 10) -> pd.Series:
    """Compute Rate of Change"""
    return ((prices - prices.shift(period)) / prices.shift(period)) * 100


def compute_williams_r(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    """Compute Williams %R"""
    highest_high = high.rolling(window=period).max()
    lowest_low = low.rolling(window=period).min()
    williams_r = -100 * ((highest_high - close) / (highest_high - lowest_low))
    return williams_r


def compute_volume_indicators(volume: pd.Series, close: pd.Series) -> dict:
    """Compute volume-based indicators"""
    # Volume moving average
    vol_ma = volume.rolling(window=20).mean()
    
    # On-Balance Volume (OBV)
    obv = (volume * np.where(close.diff() > 0, 1, 
                           np.where(close.diff() < 0, -1, 0))).cumsum()
    
    # Volume Rate of Change
    vol_roc = volume.pct_change(10) * 100
    
    return {
        'volume_ma': vol_ma,
        'obv': obv,
        'volume_roc': vol_roc
    }


def compute_features(df_raw: pd.DataFrame) -> pd.DataFrame:
    """
    Compute all technical indicators/features from raw OHLCV data.
    
    Args:
        df_raw: DataFrame with columns ['open', 'high', 'low', 'close', 'volume']
        
    Returns:
        DataFrame with original OHLCV data plus computed technical indicators
    """
    if df_raw.empty:
        raise ValueError("Input DataFrame is empty")
    
    required_cols = ['open', 'high', 'low', 'close', 'volume']
    if not all(col in df_raw.columns for col in required_cols):
        raise ValueError(f"DataFrame must contain columns: {required_cols}")
    
    # Create a copy to avoid modifying the original
    df = df_raw.copy()
    
    # Ensure we have the basic OHLCV columns
    for col in required_cols:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")
    
    # Price-based indicators
    df['rsi'] = compute_rsi(df['close'])
    
    # MACD
    macd_line, macd_signal, macd_hist = compute_macd(df['close'])
    df['macd'] = macd_line
    df['macd_signal'] = macd_signal
    df['macd_histogram'] = macd_hist
    
    # Moving Averages
    df['ma_20'] = compute_moving_average(df['close'], 20)
    df['ma_50'] = compute_moving_average(df['close'], 50)
    df['ema_12'] = compute_ema(df['close'], 12)
    df['ema_26'] = compute_ema(df['close'], 26)
    
    # Bollinger Bands
    bb_upper, bb_lower, bb_middle = compute_bollinger_bands(df['close'])
    df['bb_upper'] = bb_upper
    df['bb_lower'] = bb_lower
    df['bb_middle'] = bb_middle
    
    # Volatility indicators
    df['atr'] = compute_atr(df['high'], df['low'], df['close'])
    
    # Momentum indicators
    df['momentum'] = compute_momentum(df['close'])
    df['roc'] = compute_roc(df['close'])
    
    # Stochastic
    stoch_k, stoch_d = compute_stochastic(df['high'], df['low'], df['close'])
    df['stochastic'] = stoch_k
    df['stochastic_d'] = stoch_d
    
    # Williams %R
    df['williams_r'] = compute_williams_r(df['high'], df['low'], df['close'])
    
    # Volume indicators
    vol_indicators = compute_volume_indicators(df['volume'], df['close'])
    for name, values in vol_indicators.items():
        df[name] = values
    
    # Price ratios and relationships
    df['hl_ratio'] = df['high'] / df['low']
    df['oc_ratio'] = df['open'] / df['close']
    df['price_change'] = df['close'].pct_change()
    df['price_change_2'] = df['close'].pct_change(2)
    df['price_change_5'] = df['close'].pct_change(5)
    
    # Volatility measures
    df['close_volatility'] = df['close'].rolling(window=20).std()
    df['volume_volatility'] = df['volume'].rolling(window=20).std()
    
    # Additional trend indicators
    df['ma_20_slope'] = df['ma_20'].diff()
    df['price_distance_ma'] = (df['close'] - df['ma_20']) / df['ma_20']
    
    # Bollinger Band position
    df['bb_position'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])
    
    return df


def ensure_column_order(df_feat: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure features are in the expected order for the model.
    This should match the order used during training.
    """
    # Define the expected feature order based on training code
    expected_columns = [
        'open', 'high', 'low', 'close', 'volume',
        'rsi', 'macd', 'ma_20', 'bb_upper', 'bb_lower', 'atr', 'stochastic'
    ]
    
    # Check if all expected columns exist
    missing_cols = [col for col in expected_columns if col not in df_feat.columns]
    if missing_cols:
        print(f"Warning: Missing expected columns: {missing_cols}")
    
    # Include any additional columns that exist
    additional_cols = [col for col in df_feat.columns if col not in expected_columns]
    
    # Create the final column order
    final_columns = expected_columns + additional_cols
    
    # Filter to only include columns that actually exist in the DataFrame
    available_columns = [col for col in final_columns if col in df_feat.columns]
    
    return df_feat[available_columns].copy()


def get_feature_names() -> list:
    """Return the list of feature names in expected order"""
    return [
        'open', 'high', 'low', 'close', 'volume',
        'rsi', 'macd', 'ma_20', 'bb_upper', 'bb_lower', 'atr', 'stochastic'
    ]


def validate_features(df_feat: pd.DataFrame) -> bool:
    """
    Validate that the feature DataFrame has the expected structure
    """
    expected_cols = get_feature_names()
    
    # Check if core columns exist
    missing_required = [col for col in expected_cols if col not in df_feat.columns]
    if missing_required:
        print(f"Error: Missing required columns: {missing_required}")
        return False
    
    # Check for NaN values in critical columns
    critical_cols = ['open', 'high', 'low', 'close', 'volume']
    for col in critical_cols:
        if df_feat[col].isnull().any():
            print(f"Warning: NaN values found in critical column: {col}")
    
    return True


# Example usage and testing
if __name__ == "__main__":
    # Create sample data for testing
    np.random.seed(42)
    dates = pd.date_range(start='2023-01-01', end='2023-12-31', freq='H')
    n_points = len(dates)
    
    # Generate synthetic OHLCV data
    base_price = 1.1000
    price_changes = np.cumsum(np.random.randn(n_points) * 0.0001)
    close_prices = base_price + price_changes
    
    sample_data = pd.DataFrame({
        'timestamp': dates,
        'open': close_prices + np.random.randn(n_points) * 0.0001,
        'high': close_prices + np.abs(np.random.randn(n_points) * 0.0002),
        'low': close_prices - np.abs(np.random.randn(n_points) * 0.0002),
        'close': close_prices,
        'volume': np.random.randint(100, 1000, n_points)
    })
    
    sample_data.set_index('timestamp', inplace=True)
    
    # Test feature computation
    try:
        features_df = compute_features(sample_data)
        features_df = ensure_column_order(features_df)
        
        print("Feature computation successful!")
        print(f"Input shape: {sample_data.shape}")
        print(f"Output shape: {features_df.shape}")
        print(f"Features: {list(features_df.columns)}")
        
        # Check for NaN values
        nan_counts = features_df.isnull().sum()
        if nan_counts.sum() > 0:
            print(f"\nNaN values per column:")
            print(nan_counts[nan_counts > 0])
        
        # Validate features
        if validate_features(features_df):
            print("Feature validation passed!")
        
    except Exception as e:
        print(f"Error during feature computation: {e}")
        import traceback
        traceback.print_exc()