#!/usr/bin/env python3
"""
Complete EA Training Script - Comprehensive LSTM-CNN-Attention Model Training
This script addresses all scaling issues and ensures full EA compatibility.
"""

import argparse
import json
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import MinMaxScaler, RobustScaler, StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, callbacks, optimizers
from tensorflow.keras.models import Model
import joblib
from datetime import datetime
import logging

# Import our features module
from features import compute_features, ensure_column_order, validate_features

# Suppress warnings
warnings.filterwarnings('ignore')
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TemporalAttention(layers.Layer):
    """Enhanced temporal attention mechanism for sequence modeling"""
    def __init__(self, attn_units: int = 64, use_context: bool = True, **kwargs):
        super().__init__(**kwargs)
        self.attn_units = attn_units
        self.use_context = use_context
        self.W = layers.Dense(attn_units, activation='tanh')
        self.V = layers.Dense(1)
        if use_context:
            self.context_layer = layers.Dense(attn_units, activation='relu')

    def call(self, inputs):
        # inputs shape: (batch, timesteps, features)
        score = self.V(self.W(inputs))  # (batch, timesteps, 1)
        weights = tf.nn.softmax(score, axis=1)  # (batch, timesteps, 1)
        
        if self.use_context:
            context = tf.reduce_sum(weights * inputs, axis=1)  # (batch, features)
            context = self.context_layer(context)
            return context
        else:
            return tf.reduce_sum(weights * inputs, axis=1)

    def get_config(self):
        config = super().get_config()
        config.update({
            "attn_units": self.attn_units,
            "use_context": self.use_context
        })
        return config

def create_enhanced_model(sequence_length: int, 
                         n_features: int, 
                         prediction_steps: int,
                         attn_units: int = 64,
                         use_bidirectional: bool = True,
                         dropout_rate: float = 0.2) -> keras.Model:
    """
    Create an enhanced CNN-LSTM-Attention model for forex prediction
    Specifically designed for EA compatibility and realistic price predictions
    """
    inputs = layers.Input(shape=(sequence_length, n_features), name='market_data')
    
    # Multi-scale CNN feature extraction
    # Short-term patterns
    x1 = layers.Conv1D(32, 3, activation='relu', padding='causal')(inputs)
    x1 = layers.BatchNormalization()(x1)
    x1 = layers.Dropout(dropout_rate)(x1)
    
    # Medium-term patterns  
    x2 = layers.Conv1D(32, 7, activation='relu', padding='causal')(inputs)
    x2 = layers.BatchNormalization()(x2)
    x2 = layers.Dropout(dropout_rate)(x2)
    
    # Long-term patterns
    x3 = layers.Conv1D(32, 15, activation='relu', padding='causal')(inputs)
    x3 = layers.BatchNormalization()(x3)
    x3 = layers.Dropout(dropout_rate)(x3)
    
    # Combine multi-scale features
    x = layers.Concatenate()([x1, x2, x3])
    x = layers.Conv1D(64, 3, activation='relu', padding='causal')(x)
    x = layers.MaxPooling1D(2)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(dropout_rate)(x)
    
    # Additional convolutional layers for pattern recognition
    x = layers.Conv1D(64, 3, activation='relu', padding='causal')(x)
    x = layers.MaxPooling1D(2)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(dropout_rate)(x)
    
    # LSTM layers for temporal dependencies
    if use_bidirectional:
        x = layers.Bidirectional(layers.LSTM(128, return_sequences=True))(x)
    else:
        x = layers.LSTM(128, return_sequences=True)(x)
    x = layers.Dropout(dropout_rate + 0.1)(x)
    
    if use_bidirectional:
        x = layers.Bidirectional(layers.LSTM(64, return_sequences=True))(x)
    else:
        x = layers.LSTM(64, return_sequences=True)(x)
    x = layers.Dropout(dropout_rate + 0.1)(x)
    
    # Temporal attention mechanism
    attention_context = TemporalAttention(attn_units=attn_units, name="temporal_attention")(x)
    
    # Dense prediction layers with residual connections
    dense1 = layers.Dense(128, activation='relu')(attention_context)
    dense1 = layers.BatchNormalization()(dense1)
    dense1 = layers.Dropout(dropout_rate)(dense1)
    
    dense2 = layers.Dense(64, activation='relu')(dense1)
    dense2 = layers.BatchNormalization()(dense2)
    dense2 = layers.Dropout(dropout_rate)(dense2)
    
    # Residual connection
    if dense1.shape[-1] == dense2.shape[-1]:
        dense2 = layers.Add()([dense1, dense2])
    
    # Final prediction layer - NO ACTIVATION for regression
    predictions = layers.Dense(prediction_steps, name='price_predictions')(dense2)
    
    model = keras.Model(inputs=inputs, outputs=predictions, name="Enhanced_EA_Predictor")
    
    # Use appropriate optimizer and learning rate
    optimizer = optimizers.Adam(learning_rate=0.001, clipnorm=1.0)
    model.compile(
        optimizer=optimizer,
        loss='huber',  # More robust to outliers than MSE
        metrics=['mae', 'mse']
    )
    
    return model

def prepare_forex_data(df_raw: pd.DataFrame, target_column: str = 'close') -> tuple:
    """
    Prepare forex data with proper scaling and feature engineering
    Returns features and targets with realistic scaling
    """
    logger.info(f"Preparing forex data: {df_raw.shape} raw OHLCV bars")
    
    # Compute technical features
    df_features = compute_features(df_raw)
    df_features = ensure_column_order(df_features)
    
    # Validate features
    if not validate_features(df_features):
        raise ValueError("Feature validation failed")
    
    # Remove rows with NaN values
    initial_size = len(df_features)
    df_features = df_features.dropna()
    logger.info(f"Removed {initial_size - len(df_features)} rows with NaN values")
    
    # Extract features and target
    feature_columns = [
        'open', 'high', 'low', 'close', 'volume',
        'rsi', 'macd', 'ma_20', 'bb_upper', 'bb_lower', 
        'atr', 'stochastic'
    ]
    
    # Ensure we have all required features
    missing_features = [col for col in feature_columns if col not in df_features.columns]
    if missing_features:
        raise ValueError(f"Missing required features: {missing_features}")
    
    features = df_features[feature_columns].values
    targets = df_features[target_column].values.reshape(-1, 1)
    
    logger.info(f"Features shape: {features.shape}")
    logger.info(f"Targets shape: {targets.shape}")
    logger.info(f"Target price range: {targets.min():.5f} - {targets.max():.5f}")
    
    return features, targets, feature_columns

def create_sequences(features: np.ndarray, 
                    targets: np.ndarray, 
                    sequence_length: int, 
                    prediction_steps: int) -> tuple:
    """Create sequences for time series prediction with proper alignment"""
    X, y = [], []
    
    for i in range(sequence_length, len(features) - prediction_steps + 1):
        # Input sequence: features from i-seq_len to i
        X.append(features[i-sequence_length:i])
        # Target: prices from i to i+pred_steps
        y.append(targets[i:i+prediction_steps].flatten())
    
    X = np.array(X)
    y = np.array(y)
    
    logger.info(f"Created {len(X)} sequences")
    logger.info(f"Sequence input shape: {X.shape}")
    logger.info(f"Sequence target shape: {y.shape}")
    
    return X, y

def evaluate_model_performance(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Comprehensive model evaluation metrics"""
    metrics = {}
    
    # Overall metrics
    metrics['mse'] = mean_squared_error(y_true.flatten(), y_pred.flatten())
    metrics['rmse'] = np.sqrt(metrics['mse'])
    metrics['mae'] = mean_absolute_error(y_true.flatten(), y_pred.flatten())
    metrics['r2'] = r2_score(y_true.flatten(), y_pred.flatten())
    
    # Per-horizon metrics
    for h in range(y_true.shape[1]):
        horizon_name = f'h{h+1}'
        metrics[f'{horizon_name}_mse'] = mean_squared_error(y_true[:, h], y_pred[:, h])
        metrics[f'{horizon_name}_mae'] = mean_absolute_error(y_true[:, h], y_pred[:, h])
        metrics[f'{horizon_name}_r2'] = r2_score(y_true[:, h], y_pred[:, h])
    
    # Forex-specific metrics (percentage errors)
    mean_price = np.mean(y_true)
    metrics['mape'] = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    metrics['rmse_pips'] = metrics['rmse'] * 10000  # Assuming 4-decimal forex pair
    metrics['mae_pips'] = metrics['mae'] * 10000
    
    return metrics

def plot_predictions(y_true: np.ndarray, y_pred: np.ndarray, 
                    output_dir: Path, horizon: int = 0, 
                    n_samples: int = 200) -> None:
    """Plot prediction vs actual for visualization"""
    plt.figure(figsize=(15, 8))
    
    # Plot last n_samples
    actual = y_true[-n_samples:, horizon]
    predicted = y_pred[-n_samples:, horizon]
    
    plt.subplot(2, 2, 1)
    plt.plot(actual, label='Actual', alpha=0.7)
    plt.plot(predicted, label='Predicted', alpha=0.7)
    plt.title(f'H{horizon+1} Predictions vs Actual (Last {n_samples} samples)')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Scatter plot
    plt.subplot(2, 2, 2)
    plt.scatter(actual, predicted, alpha=0.5)
    plt.plot([actual.min(), actual.max()], [actual.min(), actual.max()], 'r--', lw=2)
    plt.xlabel('Actual')
    plt.ylabel('Predicted')
    plt.title(f'H{horizon+1} Actual vs Predicted Scatter')
    plt.grid(True, alpha=0.3)
    
    # Error distribution
    plt.subplot(2, 2, 3)
    errors = predicted - actual
    plt.hist(errors, bins=50, alpha=0.7, edgecolor='black')
    plt.xlabel('Prediction Error')
    plt.ylabel('Frequency')
    plt.title(f'H{horizon+1} Error Distribution')
    plt.axvline(0, color='red', linestyle='--')
    plt.grid(True, alpha=0.3)
    
    # Error over time
    plt.subplot(2, 2, 4)
    plt.plot(errors)
    plt.xlabel('Sample')
    plt.ylabel('Prediction Error')
    plt.title(f'H{horizon+1} Error Over Time')
    plt.axhline(0, color='red', linestyle='--')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_dir / f'predictions_h{horizon+1}.png', dpi=150, bbox_inches='tight')
    plt.close()

def save_model_artifacts(model: keras.Model,
                        feature_scaler: object,
                        price_scaler: object,
                        config: dict,
                        output_dir: Path) -> None:
    """Save all necessary model artifacts for EA deployment"""
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Save model
    model_path = output_dir / 'best_attention_model.h5'
    model.save(model_path)
    logger.info(f"Model saved to: {model_path}")
    
    # Save scalers
    joblib.dump(feature_scaler, output_dir / 'feature_scaler.pkl')
    joblib.dump(price_scaler, output_dir / 'price_scaler.pkl')
    logger.info("Scalers saved successfully")
    
    # Save configuration
    config_path = output_dir / 'model_config.json'
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    logger.info(f"Configuration saved to: {config_path}")
    
    # Save model summary
    summary_path = output_dir / 'model_summary.txt'
    with open(summary_path, 'w') as f:
        model.summary(print_fn=lambda x: f.write(x + '\n'))
    
    logger.info(f"All artifacts saved to: {output_dir}")

def main():
    parser = argparse.ArgumentParser(description='Complete EA Model Training')
    parser.add_argument('--data_path', type=str, required=True,
                       help='Path to raw OHLCV CSV file')
    parser.add_argument('--output_dir', type=str, default='models_EURUSD_H1',
                       help='Output directory for model artifacts')
    parser.add_argument('--sequence_length', type=int, default=128,
                       help='Input sequence length')
    parser.add_argument('--prediction_steps', type=int, default=5,
                       help='Number of steps to predict')
    parser.add_argument('--epochs', type=int, default=100,
                       help='Training epochs')
    parser.add_argument('--batch_size', type=int, default=64,
                       help='Batch size')
    parser.add_argument('--validation_split', type=float, default=0.2,
                       help='Validation split ratio')
    parser.add_argument('--test_split', type=float, default=0.1,
                       help='Test split ratio')
    parser.add_argument('--scaler_type', type=str, default='minmax',
                       choices=['minmax', 'standard', 'robust'],
                       help='Scaler type for features')
    parser.add_argument('--price_scaler_type', type=str, default='minmax',
                       choices=['minmax', 'standard', 'robust'],
                       help='Scaler type for prices')
    parser.add_argument('--early_stopping_patience', type=int, default=15,
                       help='Early stopping patience')
    parser.add_argument('--reduce_lr_patience', type=int, default=7,
                       help='Reduce LR patience')
    parser.add_argument('--min_lr', type=float, default=1e-7,
                       help='Minimum learning rate')
    
    args = parser.parse_args()
    
    # Setup
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    logger.info("=" * 60)
    logger.info("COMPLETE EA MODEL TRAINING")
    logger.info("=" * 60)
    logger.info(f"Data path: {args.data_path}")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Sequence length: {args.sequence_length}")
    logger.info(f"Prediction steps: {args.prediction_steps}")
    
    # Load and prepare data
    logger.info("Loading raw data...")
    df_raw = pd.read_csv(args.data_path)
    
    # Handle different timestamp formats
    if 'timestamp' in df_raw.columns:
        df_raw['timestamp'] = pd.to_datetime(df_raw['timestamp'])
        df_raw = df_raw.set_index('timestamp')
    elif 'time' in df_raw.columns:
        df_raw['time'] = pd.to_datetime(df_raw['time'])
        df_raw = df_raw.set_index('time')
    
    # Ensure we have OHLCV columns
    required_columns = ['open', 'high', 'low', 'close', 'volume']
    if not all(col in df_raw.columns for col in required_columns):
        raise ValueError(f"Missing required columns. Need: {required_columns}")
    
    df_raw = df_raw[required_columns].dropna()
    logger.info(f"Loaded {len(df_raw)} OHLCV bars")
    logger.info(f"Date range: {df_raw.index[0]} to {df_raw.index[-1]}")
    logger.info(f"Price range: {df_raw['close'].min():.5f} - {df_raw['close'].max():.5f}")
    
    # Prepare features and targets
    features, targets, feature_columns = prepare_forex_data(df_raw, 'close')
    
    # Split data (time series order preserved)
    total_samples = len(features)
    test_size = int(total_samples * args.test_split)
    val_size = int(total_samples * args.validation_split)
    train_size = total_samples - test_size - val_size
    
    # Split indices
    train_end = train_size
    val_end = train_end + val_size
    
    X_train_raw = features[:train_end]
    X_val_raw = features[train_end:val_end]
    X_test_raw = features[val_end:]
    
    y_train_raw = targets[:train_end]
    y_val_raw = targets[train_end:val_end]
    y_test_raw = targets[val_end:]
    
    logger.info(f"Train samples: {len(X_train_raw)}")
    logger.info(f"Validation samples: {len(X_val_raw)}")
    logger.info(f"Test samples: {len(X_test_raw)}")
    
    # Initialize scalers
    def get_scaler(name: str):
        """Returns a new instance of the specified scaler."""
        if name == 'minmax':
            return MinMaxScaler(feature_range=(0, 1))
        if name == 'standard':
            return StandardScaler()
        if name == 'robust':
            return RobustScaler()
        raise ValueError(f"Unknown scaler type: '{name}'")

    feature_scaler = get_scaler(args.scaler_type)
    price_scaler = get_scaler(args.price_scaler_type)
    
    # Fit scalers on training data ONLY
    logger.info("Fitting scalers on training data...")
    X_train_scaled = feature_scaler.fit_transform(X_train_raw)
    y_train_scaled = price_scaler.fit_transform(y_train_raw)
    
    # Transform validation and test data
    X_val_scaled = feature_scaler.transform(X_val_raw)
    X_test_scaled = feature_scaler.transform(X_test_raw)
    y_val_scaled = price_scaler.transform(y_val_raw)
    y_test_scaled = price_scaler.transform(y_test_raw)
    
    logger.info(f"Feature scaling: {args.scaler_type}")
    logger.info(f"Price scaling: {args.price_scaler_type}")
    logger.info(f"Scaled price range: {y_train_scaled.min():.6f} - {y_train_scaled.max():.6f}")
    
    # Create sequences
    logger.info("Creating sequences...")
    X_train_seq, y_train_seq = create_sequences(
        X_train_scaled, y_train_scaled.flatten(), 
        args.sequence_length, args.prediction_steps
    )
    X_val_seq, y_val_seq = create_sequences(
        X_val_scaled, y_val_scaled.flatten(),
        args.sequence_length, args.prediction_steps
    )
    X_test_seq, y_test_seq = create_sequences(
        X_test_scaled, y_test_scaled.flatten(),
        args.sequence_length, args.prediction_steps
    )
    
    # Build model
    logger.info("Building model...")
    n_features = X_train_seq.shape[-1]
    model = create_enhanced_model(
        sequence_length=args.sequence_length,
        n_features=n_features,
        prediction_steps=args.prediction_steps,
        attn_units=64,
        use_bidirectional=True,
        dropout_rate=0.2
    )
    
    logger.info(f"Model created with {model.count_params():,} parameters")
    model.summary(line_length=120)
    
    # Setup callbacks
    callbacks_list = [
        callbacks.EarlyStopping(
            monitor='val_loss',
            patience=args.early_stopping_patience,
            restore_best_weights=True,
            verbose=1
        ),
        callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=args.reduce_lr_patience,
            min_lr=args.min_lr,
            verbose=1
        ),
        callbacks.ModelCheckpoint(
            str(output_dir / 'checkpoint_best.h5'),
            monitor='val_loss',
            save_best_only=True,
            verbose=1
        ),
        callbacks.CSVLogger(
            str(output_dir / 'training_log.csv'),
            append=False
        )
    ]
    
    # Train model
    logger.info("Starting training...")
    history = model.fit(
        X_train_seq, y_train_seq,
        validation_data=(X_val_seq, y_val_seq),
        batch_size=args.batch_size,
        epochs=args.epochs,
        callbacks=callbacks_list,
        verbose=1,
        shuffle=False  # Important for time series
    )
    
    # Evaluate on test set
    logger.info("Evaluating on test set...")
    y_test_pred_scaled = model.predict(X_test_seq, verbose=1)
    
    # Transform back to original scale
    y_test_pred = price_scaler.inverse_transform(y_test_pred_scaled)
    y_test_true = price_scaler.inverse_transform(y_test_seq)
    
    # Calculate comprehensive metrics
    test_metrics = evaluate_model_performance(y_test_true, y_test_pred)
    
    logger.info("=" * 60)
    logger.info("TEST SET RESULTS")
    logger.info("=" * 60)
    for metric, value in test_metrics.items():
        if 'pips' in metric:
            logger.info(f"{metric.upper():>15}: {value:.2f}")
        elif 'mape' in metric:
            logger.info(f"{metric.upper():>15}: {value:.4f}%")
        else:
            logger.info(f"{metric.upper():>15}: {value:.8f}")
    
    # Create visualizations
    logger.info("Creating visualization plots...")
    for horizon in range(min(3, args.prediction_steps)):  # Plot first 3 horizons
        plot_predictions(y_test_true, y_test_pred, output_dir, horizon)
    
    # Save model configuration
    config = {
        'sequence_length': args.sequence_length,
        'n_features': n_features,
        'prediction_steps': args.prediction_steps,
        'attn_units': 64,
        'feature_columns': feature_columns,
        'scaler_type': args.scaler_type,
        'price_scaler_type': args.price_scaler_type,
        'training_samples': len(X_train_seq),
        'validation_samples': len(X_val_seq),
        'test_samples': len(X_test_seq),
        'final_metrics': test_metrics,
        'training_completed': datetime.now().isoformat(),
        'model_version': '1.0-ea-compatible'
    }
    
    # Save all artifacts
    save_model_artifacts(model, feature_scaler, price_scaler, config, output_dir)
    
    # Save training history
    history_path = output_dir / 'training_history.json'
    with open(history_path, 'w') as f:
        # Convert numpy types to native Python types for JSON serialization
        history_dict = {}
        for key, values in history.history.items():
            history_dict[key] = [float(v) for v in values]
        json.dump(history_dict, f, indent=2)
    
    logger.info("=" * 60)
    logger.info("TRAINING COMPLETED SUCCESSFULLY")
    logger.info("=" * 60)
    logger.info(f"Best validation loss: {min(history.history['val_loss']):.8f}")
    logger.info(f"Final test RMSE: {test_metrics['rmse']:.8f}")
    logger.info(f"Final test RMSE (pips): {test_metrics['rmse_pips']:.2f}")
    logger.info(f"Final test R²: {test_metrics['r2']:.4f}")
    logger.info(f"All artifacts saved to: {output_dir.absolute()}")
    
    # Print EA integration info
    logger.info("=" * 60)
    logger.info("EA INTEGRATION INFO")
    logger.info("=" * 60)
    logger.info(f"Required HistoryBars in EA: {args.sequence_length}")
    logger.info(f"Expected features per bar: {n_features}")
    logger.info(f"Total data points per request: {args.sequence_length * n_features}")
    logger.info(f"Server endpoint: /predict")
    logger.info("Model is ready for EA deployment!")

if __name__ == '__main__':
    main()