#!/usr/bin/env python3
"""
Fixed Flask Prediction Server for Return-Based Model
Handles realistic percentage return predictions and converts to prices
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import pandas as pd
import joblib
import logging
from pathlib import Path
import json
from datetime import datetime
import tensorflow as tf
from tensorflow.keras.models import load_model
from features import compute_features, ensure_column_order

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
CORS(app)

# Global variables for model and scalers
model = None
feature_scaler = None
model_config = None
sequence_length = 64
prediction_steps = 5
feature_columns = None
is_return_based_model = False

class TemporalAttention(tf.keras.layers.Layer):
    """Custom layer for model loading"""
    def __init__(self, attn_units: int = 32, **kwargs):
        super().__init__(**kwargs)
        self.attn_units = attn_units
        self.W = tf.keras.layers.Dense(attn_units, activation='tanh')
        self.V = tf.keras.layers.Dense(1)

    def call(self, inputs):
        score = self.V(self.W(inputs))
        weights = tf.nn.softmax(score, axis=1)
        context = tf.reduce_sum(weights * inputs, axis=1)
        return context

    def get_config(self):
        config = super().get_config()
        config.update({"attn_units": self.attn_units})
        return config

def load_model_artifacts(model_dir: str = "models_EURUSD_H1_fixed"):
    """Load the fixed return-based model and preprocessing artifacts"""
    global model, feature_scaler, model_config, sequence_length, prediction_steps, feature_columns, is_return_based_model
    
    model_path = Path(model_dir)
    
    try:
        # Load model with custom objects
        logger.info(f"Loading fixed model from {model_path}")
        model = load_model(
            model_path / 'best_attention_model.h5',
            custom_objects={'TemporalAttention': TemporalAttention}
        )
        
        # Load feature scaler (no price scaler needed for return-based model)
        feature_scaler = joblib.load(model_path / 'feature_scaler.pkl')
        
        # Load configuration
        with open(model_path / 'model_config.json', 'r') as f:
            model_config = json.load(f)
        
        sequence_length = model_config['sequence_length']
        prediction_steps = model_config['prediction_steps']
        feature_columns = model_config['feature_columns']
        is_return_based_model = model_config.get('model_type') == 'return_prediction'
        
        logger.info("Fixed model loaded successfully!")
        logger.info(f"Model type: {'Return-based' if is_return_based_model else 'Price-based'}")
        logger.info(f"Sequence length: {sequence_length}")
        logger.info(f"Prediction steps: {prediction_steps}")
        logger.info(f"Feature columns: {len(feature_columns)}")
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to load model: {e}")
        return False

def prepare_ea_data_for_returns(data_array: list, current_price: float):
    """Convert EA data format to return-based model input format"""
    try:
        # The EA still sends the same OHLCV + technical indicators
        # But we need to convert to the return-based features the model expects
        
        features_per_bar = 12  # Still the same format from EA
        expected_total_features = sequence_length * features_per_bar
        
        if len(data_array) != expected_total_features:
            logger.warning(f"Expected {expected_total_features} features, got {len(data_array)}")
            return None
        
        # Reshape to (sequence_length, features_per_bar)
        raw_features_2d = np.array(data_array).reshape(sequence_length, features_per_bar)
        
        # Extract the raw OHLCV and technical data
        # Format: [open, high, low, close, volume, rsi, macd, ma_20, bb_upper, bb_lower, atr, stochastic]
        opens = raw_features_2d[:, 0]
        highs = raw_features_2d[:, 1]
        lows = raw_features_2d[:, 2]
        closes = raw_features_2d[:, 3]
        volumes = raw_features_2d[:, 4]
        rsis = raw_features_2d[:, 5]
        macds = raw_features_2d[:, 6]
        ma_20s = raw_features_2d[:, 7]
        bb_uppers = raw_features_2d[:, 8]
        bb_lowers = raw_features_2d[:, 9]
        atrs = raw_features_2d[:, 10]
        stochastics = raw_features_2d[:, 11]
        
        # Convert to the features the return-based model expects
        # Based on the training script: ['rsi', 'macd', 'atr', 'stochastic', 'volume', 'price_norm', 'high_norm', 'low_norm', 'open_norm']
        
        model_features = np.zeros((sequence_length, len(feature_columns)))
        
        for i in range(sequence_length):
            # Technical indicators (direct copy)
            if 'rsi' in feature_columns:
                model_features[i, feature_columns.index('rsi')] = rsis[i]
            if 'macd' in feature_columns:
                model_features[i, feature_columns.index('macd')] = macds[i]
            if 'atr' in feature_columns:
                model_features[i, feature_columns.index('atr')] = atrs[i]
            if 'stochastic' in feature_columns:
                model_features[i, feature_columns.index('stochastic')] = stochastics[i]
            if 'volume' in feature_columns:
                model_features[i, feature_columns.index('volume')] = volumes[i]
            
            # Normalized price features (calculated on the fly)
            current_close = closes[i]
            if 'price_norm' in feature_columns:
                # Simple normalization relative to sequence average
                avg_close = np.mean(closes[:i+1]) if i > 0 else current_close
                std_close = np.std(closes[:i+1]) if i > 0 else 1.0
                model_features[i, feature_columns.index('price_norm')] = (current_close - avg_close) / max(std_close, 1e-8)
            
            if 'high_norm' in feature_columns:
                model_features[i, feature_columns.index('high_norm')] = (highs[i] - current_close) / current_close * 100
            if 'low_norm' in feature_columns:
                model_features[i, feature_columns.index('low_norm')] = (lows[i] - current_close) / current_close * 100
            if 'open_norm' in feature_columns:
                model_features[i, feature_columns.index('open_norm')] = (opens[i] - current_close) / current_close * 100
        
        # Scale features
        features_scaled = feature_scaler.transform(model_features)
        
        # Reshape for model input: (1, sequence_length, n_features)
        model_input = features_scaled.reshape(1, sequence_length, len(feature_columns))
        
        logger.info(f"Prepared return-based model input shape: {model_input.shape}")
        return model_input
        
    except Exception as e:
        logger.error(f"Error preparing EA data for returns: {e}")
        return None

def convert_returns_to_prices(return_predictions: np.ndarray, current_price: float) -> list:
    """Convert percentage return predictions back to absolute prices"""
    try:
        # return_predictions shape: (1, prediction_steps)
        returns = return_predictions[0]  # Get first (and only) sample
        
        prices = []
        for i, return_pct in enumerate(returns):
            # Clip extreme predictions to realistic range
            return_pct = np.clip(return_pct, -2.0, 2.0)  # Max 2% per hour
            
            # Convert percentage return to absolute price
            # Future price = current_price * (1 + return_percentage/100)
            future_price = current_price * (1 + return_pct / 100)
            prices.append(float(future_price))
        
        return prices
        
    except Exception as e:
        logger.error(f"Error converting returns to prices: {e}")
        return [current_price] * prediction_steps  # Return safe fallback

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    status = {
        'status': 'healthy',
        'model_loaded': model is not None,
        'model_type': 'return_based' if is_return_based_model else 'price_based',
        'timestamp': datetime.now().isoformat(),
        'version': '2.0-fixed'
    }
    
    if model is not None:
        status['model_info'] = {
            'sequence_length': sequence_length,
            'prediction_steps': prediction_steps,
            'feature_count': len(feature_columns) if feature_columns else 0,
            'is_return_based': is_return_based_model
        }
    
    return jsonify(status)

@app.route('/predict', methods=['POST'])
def predict():
    """Main prediction endpoint for fixed return-based model"""
    try:
        # Check if model is loaded
        if model is None:
            return jsonify({
                'error': 'Model not loaded',
                'success': False
            }), 500
        
        # Parse request data
        data = request.get_json()
        if not data:
            return jsonify({
                'error': 'No JSON data received',
                'success': False
            }), 400
        
        # Extract required fields
        symbol = data.get('symbol', 'UNKNOWN')
        timeframe = data.get('timeframe', 'UNKNOWN')
        current_price = data.get('current_price', 0.0)
        market_data = data.get('data', [])
        
        logger.info(f"Prediction request: {symbol} {timeframe}, price={current_price}")
        
        # Validate input data
        if not market_data:
            return jsonify({
                'error': 'No market data provided',
                'success': False
            }), 400
        
        if current_price <= 0:
            return jsonify({
                'error': 'Invalid current price',
                'success': False
            }), 400
        
        # Prepare data for return-based model
        model_input = prepare_ea_data_for_returns(market_data, current_price)
        if model_input is None:
            return jsonify({
                'error': 'Failed to prepare input data for return-based model',
                'success': False
            }), 400
        
        # Make prediction (returns percentage changes)
        logger.info("Making return prediction...")
        return_predictions = model.predict(model_input, verbose=0)
        
        # Convert returns back to absolute prices for EA compatibility
        hourly_predictions = convert_returns_to_prices(return_predictions, current_price)
        
        # Generate conservative daily predictions based on hourly returns
        daily_predictions = []
        for i in range(prediction_steps):
            # Calculate cumulative return effect for multi-day prediction
            hourly_return = (hourly_predictions[i] - current_price) / current_price
            # Scale conservatively for daily (assume daily return is ~3x hourly but capped)
            daily_return = np.clip(hourly_return * (i + 1) * 0.5, -0.05, 0.05)  # Max 5% daily
            daily_price = current_price * (1 + daily_return)
            daily_predictions.append(float(daily_price))
        
        # Log predictions
        logger.info("Return predictions converted to prices successfully")
        for i, (h_pred, d_pred) in enumerate(zip(hourly_predictions, daily_predictions)):
            h_change = ((h_pred - current_price) / current_price) * 100
            d_change = ((d_pred - current_price) / current_price) * 100
            logger.info(f"  H{i+1}: {h_pred:.5f} ({h_change:+.3f}%)")
            logger.info(f"  D{i+1}: {d_pred:.5f} ({d_change:+.3f}%)")
        
        # Return predictions in expected format
        response = {
            'success': True,
            'symbol': symbol,
            'timeframe': timeframe,
            'current_price': current_price,
            'timestamp': datetime.now().isoformat(),
            'hourly_predictions': hourly_predictions,
            'daily_predictions': daily_predictions,
            'model_info': {
                'sequence_length': sequence_length,
                'prediction_steps': prediction_steps,
                'model_type': 'return_based',
                'version': '2.0-fixed'
            }
        }
        
        return jsonify(response)
        
    except Exception as e:
        logger.error(f"Prediction error: {str(e)}")
        return jsonify({
            'error': f'Prediction failed: {str(e)}',
            'success': False
        }), 500

@app.route('/model/status', methods=['GET'])
def model_status():
    """Get detailed model status"""
    if model is None:
        return jsonify({
            'loaded': False,
            'error': 'Model not loaded'
        })
    
    try:
        status = {
            'loaded': True,
            'model_config': model_config,
            'input_shape': model.input_shape,
            'output_shape': model.output_shape,
            'parameter_count': model.count_params(),
            'feature_columns': feature_columns,
            'is_return_based': is_return_based_model,
            'version': '2.0-fixed'
        }
        return jsonify(status)
        
    except Exception as e:
        return jsonify({
            'loaded': True,
            'error': f'Status check failed: {str(e)}'
        })

@app.route('/model/reload', methods=['POST'])
def reload_model():
    """Reload model artifacts"""
    data = request.get_json() or {}
    model_dir = data.get('model_dir', 'models_EURUSD_H1_fixed')
    
    if load_model_artifacts(model_dir):
        return jsonify({
            'success': True,
            'message': 'Fixed return-based model reloaded successfully'
        })
    else:
        return jsonify({
            'success': False,
            'message': 'Failed to reload model'
        }), 500

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Fixed Prediction Server')
    parser.add_argument('--model_dir', type=str, default='models_EURUSD_H1_fixed',
                       help='Directory containing fixed model artifacts')
    parser.add_argument('--host', type=str, default='127.0.0.1',
                       help='Server host')
    parser.add_argument('--port', type=int, default=8000,
                       help='Server port')
    parser.add_argument('--debug', action='store_true',
                       help='Enable debug mode')
    
    args = parser.parse_args()
    
    # Load model artifacts
    logger.info("Starting Fixed Prediction Server...")
    logger.info(f"Model directory: {args.model_dir}")
    
    if not load_model_artifacts(args.model_dir):
        logger.error("Failed to load model artifacts. Server will start but predictions will fail.")
    
    # Start server
    logger.info(f"Starting server on {args.host}:{args.port}")
    app.run(
        host=args.host,
        port=args.port,
        debug=args.debug,
        threaded=True
    )

if __name__ == '__main__':
    main()