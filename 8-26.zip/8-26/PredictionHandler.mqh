//+------------------------------------------------------------------+
//|                                            PredictionHandler.mqh |
//+------------------------------------------------------------------+
#property copyright "Copyright 2025, MetaQuotes Ltd."
#property link      "https://www.mql5.com"

struct SPredictionData{ datetime timestamp; double price; double confidence; int timeframe; };

class CPredictionHandler
{
private:
    int hourlyPredictionCount; int dailyPredictionCount;
    SPredictionData lastHourlyPredictions[]; SPredictionData lastDailyPredictions[];
public:
    CPredictionHandler(); ~CPredictionHandler();
    bool Initialize(int hourlyCount, int dailyCount);
    bool ParsePredictions(string jsonResponse, double &hourlyPreds[], double &dailyPreds[]);
private:
    bool ParseJSONArray(string json, string arrayName, double &values[]);
};
CPredictionHandler::CPredictionHandler(){ hourlyPredictionCount=5; dailyPredictionCount=5; }
CPredictionHandler::~CPredictionHandler(){ ArrayFree(lastHourlyPredictions); ArrayFree(lastDailyPredictions); }
bool CPredictionHandler::Initialize(int hourlyCount, int dailyCount)
{
    if(hourlyCount<=0 || dailyCount<=0) return false;
    hourlyPredictionCount=hourlyCount; dailyPredictionCount=dailyCount;
    ArrayResize(lastHourlyPredictions, hourlyPredictionCount); ArrayResize(lastDailyPredictions, dailyPredictionCount);
    Print("PredictionHandler: Initialized for ", hourlyCount, " hourly and ", dailyCount, " daily predictions");
    return true;
}
bool CPredictionHandler::ParsePredictions(string jsonResponse, double &hourlyPreds[], double &dailyPreds[])
{
    if(StringLen(jsonResponse)==0) return false;
    if(!ParseJSONArray(jsonResponse, "hourly", hourlyPreds)){ Print("PredictionHandler: Failed to parse 'hourly' predictions"); return false; }
    if(!ParseJSONArray(jsonResponse, "daily", dailyPreds)){ Print("PredictionHandler: Failed to parse 'daily' predictions"); return false; }
    return true;
}
bool CPredictionHandler::ParseJSONArray(string json, string arrayName, double &values[])
{
    string searchKey = "\"" + arrayName + "\":[";
    int startPos = StringFind(json, searchKey);
    if(startPos == -1) return false;
    startPos += StringLen(searchKey);
    int endPos = StringFind(json, "]", startPos);
    if(endPos == -1) return false;
    string arrayContent = StringSubstr(json, startPos, endPos - startPos);
    string elements[];
    if(StringSplit(arrayContent, ',', elements) > 0)
    {
        ArrayResize(values, ArraySize(elements));
        for(int i = 0; i < ArraySize(elements); i++) values[i] = StringToDouble(elements[i]);
        return true;
    }
    return false;
}